// Put your keys here (no need to rebuild the site code).
// formKey: free access key from https://web3forms.com (enter the email that should receive leads)
// gaId:    your Google Analytics ID, like 'G-ABC123XYZ' (leave empty to disable analytics)
window.LH_CONFIG = { formKey: 'PASTE_YOUR_WEB3FORMS_ACCESS_KEY_HERE', gaId: '' };
