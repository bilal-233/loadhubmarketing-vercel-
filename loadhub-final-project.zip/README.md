# Loadhub Marketing (React + Vite)

Every page is pre-rendered to real HTML at build time (good for Google and link previews).

## Run locally
    npm install
    npm run dev       # development
    npm run build     # production build into dist/

## Deploy on Vercel
Push to GitHub, then Vercel -> Add New Project. Settings are in vercel.json.
Or drag the built `dist` folder to vercel.com/drop.

## Before going live: public/config.js
- formKey: Web3Forms access key (web3forms.com) so the contact/partner forms email you
- gaId: Google Analytics ID (optional)

## Add social profiles
Edit the `social` list at the top of src/components/Footer.jsx.
