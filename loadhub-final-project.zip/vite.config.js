import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: {
      output: {
        manualChunks: (id) => (/node_modules\/(react|react-dom|react-router|react-router-dom|scheduler|@remix-run)\//.test(id) ? 'vendor' : undefined),
      },
    },
  },
})
