import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Head from './components/Head'
import { pages } from './routes'

export default function App() {
  const home = pages.find((p) => p.slug === 'home')
  return (
    <Layout>
      <Routes>
        {pages.map(({ slug, path, Component, head }) => (
          <Route key={slug} path={path} element={<><Head head={head} /><Component /></>} />
        ))}
        <Route path="/index.html" element={<><Head head={home.head} /><home.Component /></>} />
      </Routes>
    </Layout>
  )
}
