import { renderToString } from 'react-dom/server'
import { StaticRouter } from 'react-router-dom/server'
import App from './App'
import { pages, fileFor } from './routes'
import { headHtml } from './lib/head'

export function render(url) {
  return renderToString(<StaticRouter location={url}><App /></StaticRouter>)
}

export const routes = pages.map((p) => ({
  file: fileFor(p),
  url: p.slug === 'notfound' ? '/__not-found__' : p.path,
  head: headHtml(p.head),
}))
