const mods = import.meta.glob('./pages/*.jsx', { eager: true })

export const pages = Object.entries(mods).map(([file, m]) => {
  const slug = file.match(/\/([^/]+)\.jsx$/)[1]
  const path = slug === 'home' ? '/' : slug === 'notfound' ? '*' : `/${slug}.html`
  return { slug, path, Component: m.default, head: m.head }
})

// Where each page is written at build time (e.g. /about.html -> about.html)
export function fileFor(p) {
  if (p.slug === 'home') return 'index.html'
  if (p.slug === 'notfound') return '404.html'
  return `${p.slug}.html`
}
