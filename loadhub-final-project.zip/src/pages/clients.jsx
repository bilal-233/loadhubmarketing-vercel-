import { Link } from 'react-router-dom'

export const head = {
  "title": "Insurance Agencies, Brokers and Networks | Loadhub Marketing",
  "tags": [
    {
      "name": "description",
      "content": "Loadhub Marketing works with insurance agencies, brokers, carriers and call centers that need compliant insurance leads in the United States."
    },
    {
      "name": "robots",
      "content": "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"
    },
    {
      "property": "og:type",
      "content": "website"
    },
    {
      "property": "og:title",
      "content": "Insurance Agencies, Brokers and Networks | Loadhub Marketing"
    },
    {
      "property": "og:description",
      "content": "Loadhub Marketing works with insurance agencies, brokers, carriers and call centers that need compliant insurance leads in the United States."
    },
    {
      "property": "og:url",
      "content": "https://loadhubmarketing.com/clients.html"
    },
    {
      "property": "og:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    },
    {
      "property": "og:image:width",
      "content": "1200"
    },
    {
      "property": "og:image:height",
      "content": "630"
    },
    {
      "property": "og:image:alt",
      "content": "Loadhub Marketing, insurance lead generation"
    },
    {
      "property": "og:site_name",
      "content": "Loadhub Marketing"
    },
    {
      "property": "og:locale",
      "content": "en_US"
    },
    {
      "name": "twitter:card",
      "content": "summary_large_image"
    },
    {
      "name": "twitter:title",
      "content": "Insurance Agencies, Brokers and Networks | Loadhub Marketing"
    },
    {
      "name": "twitter:description",
      "content": "Loadhub Marketing works with insurance agencies, brokers, carriers and call centers that need compliant insurance leads in the United States."
    },
    {
      "name": "twitter:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    }
  ],
  "canonical": "https://loadhubmarketing.com/clients.html"
}

export default function Clients() {
  return (
    <main>
        <section className="phead">
          <div className="wrap" style={{textAlign:"center"}}>
            <h1 className="nm" style={{fontSize:"clamp(2rem,4.5vw,3.2rem)"}}>
              {"Who we "}
              <span>
                work with
              </span>
            </h1>
            <p className="lead" style={{margin:"14px auto 0"}}>
              We work with the people who sell insurance and need a steady flow of shoppers.
            </p>
          </div>
        </section>
        <section style={{paddingTop:"20px"}}>
          <div className="wrap">
            <div className="grid g4">
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-building" />
                  </svg>
                </div>
                <h3>
                  Insurance agencies
                </h3>
                <p>
                  Captive and independent agencies that want more quote requests.
                </p>
              </div>
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-user-tie" />
                  </svg>
                </div>
                <h3>
                  Independent agents and brokers
                </h3>
                <p>
                  Producers who need fresh leads in the states they are licensed in.
                </p>
              </div>
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-shield-halved" />
                  </svg>
                </div>
                <h3>
                  Carriers and MGAs
                </h3>
                <p>
                  Direct-to-consumer teams that buy leads by line and state.
                </p>
              </div>
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-headset" />
                  </svg>
                </div>
                <h3>
                  Networks and call centers
                </h3>
                <p>
                  Buyers who run phone sales or resell leads.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="alt">
          <div className="wrap">
            <div className="head c">
              <h2>
                Lines of insurance we cover
              </h2>
            </div>
            <div className="tags" style={{justifyContent:"center"}}>
              <span>
                Auto Insurance
              </span>
              <span>
                Home Insurance
              </span>
              <span>
                Health Insurance
              </span>
              <span>
                Life Insurance
              </span>
              <span>
                Dental &amp; Vision
              </span>
              <span>
                Travel Insurance
              </span>
              <span>
                Pet Insurance
              </span>
              <span>
                Umbrella Insurance
              </span>
              <span>
                Flood &amp; Earthquake Insurance
              </span>
              <span>
                General Liability
              </span>
              <span>
                Commercial Auto
              </span>
              <span>
                Workers’ Compensation
              </span>
              <span>
                Professional Liability (E&amp;O)
              </span>
              <span>
                Business Owner’s Policy (BOP)
              </span>
              <span>
                Cyber Insurance
              </span>
              <span>
                Commercial Property
              </span>
              <span>
                Group Health
              </span>
              <span>
                Disability Insurance
              </span>
              <span>
                Long-Term Care
              </span>
              <span>
                Annuities / Retirement
              </span>
              <span>
                Trucking Insurance
              </span>
            </div>
          </div>
        </section>
        <section>
          <div className="wrap">
            <div className="band">
              <div>
                <h2>
                  Want to work together?
                </h2>
                <p>
                  Tell us your states and the lines you sell.
                </p>
              </div>
              <Link to="/partner.html" className="btn s">
                Partner with us
              </Link>
            </div>
          </div>
        </section>
      </main>
  )
}
