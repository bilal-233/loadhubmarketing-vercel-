import { Link } from 'react-router-dom'

export const head = {
  "title": "About M. Tayyab and Loadhub Marketing | Lead Generation USA",
  "tags": [
    {
      "name": "description",
      "content": "Meet M. Tayyab, CEO of Loadhub Marketing, a U.S. performance marketing and lead generation company based in Michigan with 10 years of experience."
    },
    {
      "name": "robots",
      "content": "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"
    },
    {
      "property": "og:type",
      "content": "website"
    },
    {
      "property": "og:title",
      "content": "About M. Tayyab and Loadhub Marketing | Lead Generation USA"
    },
    {
      "property": "og:description",
      "content": "Meet M. Tayyab, CEO of Loadhub Marketing, a U.S. performance marketing and lead generation company based in Michigan with 10 years of experience."
    },
    {
      "property": "og:url",
      "content": "https://loadhubmarketing.com/about.html"
    },
    {
      "property": "og:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    },
    {
      "property": "og:image:width",
      "content": "1200"
    },
    {
      "property": "og:image:height",
      "content": "630"
    },
    {
      "property": "og:image:alt",
      "content": "Loadhub Marketing, insurance lead generation"
    },
    {
      "property": "og:site_name",
      "content": "Loadhub Marketing"
    },
    {
      "property": "og:locale",
      "content": "en_US"
    },
    {
      "name": "twitter:card",
      "content": "summary_large_image"
    },
    {
      "name": "twitter:title",
      "content": "About M. Tayyab and Loadhub Marketing | Lead Generation USA"
    },
    {
      "name": "twitter:description",
      "content": "Meet M. Tayyab, CEO of Loadhub Marketing, a U.S. performance marketing and lead generation company based in Michigan with 10 years of experience."
    },
    {
      "name": "twitter:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    }
  ],
  "canonical": "https://loadhubmarketing.com/about.html"
}

export default function About() {
  return (
    <main>
        <section className="phead">
          <div className="wrap split" style={{alignItems:"center"}}>
            <figure className="shot rv">
              <img src="/m-tayyab-ceo-loadhub-marketing.jpg" alt="M. Tayyab at his desk in the Loadhub Marketing office" width="1024" height="683" fetchpriority="high" />
              <figcaption>
                M. Tayyab
                <small>
                  CEO, Loadhub Marketing
                </small>
              </figcaption>
            </figure>
            <div>
              <h1 className="nm" style={{fontSize:"clamp(2rem,4.5vw,3.2rem)"}}>
                {"M. "}
                <span>
                  Tayyab
                </span>
              </h1>
              <p className="lead" style={{marginTop:"14px"}}>
                M. Tayyab is the CEO of Loadhub Marketing, a performance marketing and lead generation company serving the United States from Brownstown Township, Michigan.
              </p>
              <p className="lead" style={{marginTop:"14px"}}>
                With 10 years of experience in this field, M. Tayyab leads every partnership with a focus on lead quality and compliance.
              </p>
              <p className="lead" style={{marginTop:"14px"}}>
                Loadhub Marketing connects consumers researching auto, health, finance and insurance products with the advertisers, affiliate networks and brokers that serve them.
              </p>
              <p className="lead" style={{marginTop:"14px"}}>
                The focus is simple: deliver compliant, high-intent leads and build long-term partnerships based on trust and clear reporting.
              </p>
              <div className="tags" style={{marginTop:"18px"}}>
                <span>
                  CEO, Loadhub Marketing
                </span>
                <span>
                  10 years of experience
                </span>
                <span>
                  1,000+ satisfied clients
                </span>
              </div>
              <div className="act" style={{marginTop:"18px"}}>
                <a className="pill t" href="#" aria-label="LinkedIn">
                  <svg className="i" aria-hidden="true">
                    <use href="#brands-linkedin-in" />
                  </svg>
                  {" LinkedIn"}
                </a>
                <a className="pill t" href="https://t.me/Loadhub_america" target="_blank" rel="noopener">
                  <svg className="i" aria-hidden="true">
                    <use href="#brands-telegram" />
                  </svg>
                  {" Telegram"}
                </a>
                <a className="pill t" href="#" aria-label="Teams">
                  <svg className="i" aria-hidden="true">
                    <use href="#brands-microsoft" />
                  </svg>
                  {" Teams"}
                </a>
                <a className="pill w" href="https://wa.me/16468956658" target="_blank" rel="noopener">
                  <svg className="i" aria-hidden="true">
                    <use href="#brands-whatsapp" />
                  </svg>
                  {" WhatsApp"}
                </a>
              </div>
            </div>
          </div>
        </section>
        <section className="alt">
          <div className="wrap">
            <div className="head c">
              <h2>
                What we stand for
              </h2>
            </div>
            <div className="grid g3">
              <div className="feat rv">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-bullseye" />
                </svg>
                <div>
                  <h3>
                    Our focus
                  </h3>
                  <p>
                    Intent-based traffic with clear sourcing and quality checks.
                  </p>
                </div>
              </div>
              <div className="feat rv">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-user-shield" />
                </svg>
                <div>
                  <h3>
                    Our standards
                  </h3>
                  <p>
                    Consent, disclosure and data care come before volume.
                  </p>
                </div>
              </div>
              <div className="feat rv">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-handshake" />
                </svg>
                <div>
                  <h3>
                    Our approach
                  </h3>
                  <p>
                    Long-term partnerships built on honest reporting.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section>
          <div className="wrap">
            <div className="band">
              <div>
                <h2>
                  Let’s work together
                </h2>
                <p>
                  Send us your offer and target markets.
                </p>
              </div>
              <Link to="/partner.html" className="btn s">
                Partner with us
              </Link>
            </div>
          </div>
        </section>
        <script type="application/ld+json" dangerouslySetInnerHTML={{__html:"{\"@context\":\"https://schema.org\",\"@type\":\"Person\",\"name\":\"M. Tayyab\",\"jobTitle\":\"CEO\",\"worksFor\":{\"@id\":\"https://loadhubmarketing.com/#org\"},\"image\":\"https://loadhubmarketing.com/m-tayyab-ceo-loadhub-marketing.jpg\",\"url\":\"https://loadhubmarketing.com/about.html\"}"}} />
      </main>
  )
}
