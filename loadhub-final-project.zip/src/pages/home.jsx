import { Link } from 'react-router-dom'

export const head = {
  "title": "Loadhub Marketing | Insurance Lead Generation USA",
  "tags": [
    {
      "name": "description",
      "content": "Loadhub Marketing is a U.S. performance marketing and lead generation partner for auto, health, finance and insurance brands. Compliant, real-time leads."
    },
    {
      "name": "robots",
      "content": "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"
    },
    {
      "property": "og:type",
      "content": "website"
    },
    {
      "property": "og:title",
      "content": "Loadhub Marketing | Insurance Lead Generation USA"
    },
    {
      "property": "og:description",
      "content": "Loadhub Marketing is a U.S. performance marketing and lead generation partner for auto, health, finance and insurance brands. Compliant, real-time leads."
    },
    {
      "property": "og:url",
      "content": "https://loadhubmarketing.com/"
    },
    {
      "property": "og:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    },
    {
      "property": "og:image:width",
      "content": "1200"
    },
    {
      "property": "og:image:height",
      "content": "630"
    },
    {
      "property": "og:image:alt",
      "content": "Loadhub Marketing, insurance lead generation"
    },
    {
      "property": "og:site_name",
      "content": "Loadhub Marketing"
    },
    {
      "property": "og:locale",
      "content": "en_US"
    },
    {
      "name": "twitter:card",
      "content": "summary_large_image"
    },
    {
      "name": "twitter:title",
      "content": "Loadhub Marketing | Insurance Lead Generation USA"
    },
    {
      "name": "twitter:description",
      "content": "Loadhub Marketing is a U.S. performance marketing and lead generation partner for auto, health, finance and insurance brands. Compliant, real-time leads."
    },
    {
      "name": "twitter:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    }
  ],
  "canonical": "https://loadhubmarketing.com/"
}

export default function Home() {
  return (
    <main>
        <section className="hero">
          <div className="wrap">
            <div>
              <span className="badge">
                Insurance Lead Generation
              </span>
              <h1>
                Insurance leads your agents will actually want to call
              </h1>
              <p>
                We are a lead generation company based in Michigan. Someone asks for a quote, we check their details and consent, and the lead goes straight to your agency, call center or network. Run by M. Tayyab, with 10 years in this business.
              </p>
              <div className="ab">
                <Link to="/partner.html" className="btn p">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-handshake" />
                  </svg>
                  {" Partner with us"}
                </Link>
                <Link to="/contact.html" className="btn o">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-envelope" />
                  </svg>
                  {" Get in touch"}
                </Link>
              </div>
            </div>
            <div>
              <svg className="hub" viewBox="0 0 460 420" role="img" aria-label="Leads from auto, health, finance and insurance flowing into one hub">
                <circle className="pulse" cx="230" cy="210" r="46" />
                <circle className="pulse" cx="230" cy="210" r="46" style={{animationDelay:"1.3s"}} />
                {" "}
                <g id="ps">
                  <path className="ln" d="M110 80Q170 120 205 185" />
                  <path className="ln" d="M350 80Q290 120 255 185" />
                  <path className="ln" d="M110 340Q170 300 205 235" />
                  <path className="ln" d="M350 340Q290 300 255 235" />
                </g>
                {" "}
                <g fill="#12b894">
                  <circle r="5" opacity="0">
                    <animateMotion dur="2.8s" begin="0s" repeatCount="indefinite" path="M110 80Q170 120 230 210" />
                    <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="2.8s" begin="0s" repeatCount="indefinite" />
                  </circle>
                  <circle r="5" opacity="0">
                    <animateMotion dur="3.2s" begin=".6s" repeatCount="indefinite" path="M350 80Q290 120 230 210" />
                    <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="3.2s" begin=".6s" repeatCount="indefinite" />
                  </circle>
                  <circle r="5" opacity="0">
                    <animateMotion dur="3s" begin="1.1s" repeatCount="indefinite" path="M110 340Q170 300 230 210" />
                    <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="3s" begin="1.1s" repeatCount="indefinite" />
                  </circle>
                  <circle r="5" opacity="0">
                    <animateMotion dur="3.4s" begin="1.6s" repeatCount="indefinite" path="M350 340Q290 300 230 210" />
                    <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="3.4s" begin="1.6s" repeatCount="indefinite" />
                  </circle>
                </g>
                {" "}
                <g transform="translate(184 164) scale(1.92)">
                  <path d="M24 3 42 10v14c0 11-8 18-18 21C14 42 6 35 6 24V10z" fill="#1e5bff" />
                  <g stroke="#fff" strokeWidth="2.2" strokeLinecap="round">
                    <path d="M24 24 15 16M24 24l9-8M24 24v12" />
                  </g>
                  <g fill="#fff">
                    <circle cx="24" cy="24" r="4.5" />
                    <circle cx="14" cy="15" r="3" />
                    <circle cx="34" cy="15" r="3" />
                    <circle cx="24" cy="37" r="3" />
                  </g>
                </g>
                {" "}
                <g className="nd">
                  <rect x="50" y="58" width="110" height="44" rx="22" />
                  <text x="105" y="86" textAnchor="middle">
                    Auto
                  </text>
                  <rect x="300" y="58" width="110" height="44" rx="22" />
                  <text x="355" y="86" textAnchor="middle">
                    Health
                  </text>
                  <rect x="50" y="318" width="110" height="44" rx="22" />
                  <text x="105" y="346" textAnchor="middle">
                    Finance
                  </text>
                  <rect x="300" y="318" width="110" height="44" rx="22" />
                  <text x="355" y="346" textAnchor="middle">
                    Insurance
                  </text>
                </g>
              </svg>
            </div>
          </div>
        </section>
        <div className="wrap">
          <div className="stats">
            <div>
              <b>
                10+
              </b>
              <span>
                Years in lead generation
              </span>
            </div>
            <div>
              <b data-n="50">
                0
              </b>
              <span>
                U.S. states covered
              </span>
            </div>
            <div>
              <b data-n="1000" data-s="+">
                0
              </b>
              <span>
                Satisfied clients
              </span>
            </div>
            <div>
              <b>
                <svg className="i" aria-hidden="true">
                  <use href="#solid-user-shield" />
                </svg>
              </b>
              <span>
                Consent on every lead
              </span>
            </div>
          </div>
        </div>
        <section className="alt">
          <div className="wrap">
            <div className="head">
              <h2>
                What we do for insurance brands
              </h2>
              <p className="lead">
                We find people shopping for coverage and hand them to you with the details already checked.
              </p>
            </div>
            <div className="grid g3">
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-bullseye" />
                  </svg>
                </div>
                <h3>
                  Insurance lead generation
                </h3>
                <p>
                  People shopping for auto, home, health, life and business coverage.
                </p>
              </div>
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-file-invoice-dollar" />
                  </svg>
                </div>
                <h3>
                  CPL and CPA campaigns
                </h3>
                <p>
                  Pay per lead or per action, whichever fits your model.
                </p>
              </div>
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-circle-check" />
                  </svg>
                </div>
                <h3>
                  Checked before delivery
                </h3>
                <p>
                  Phone, email and consent are verified before a lead reaches you.
                </p>
              </div>
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-bolt" />
                  </svg>
                </div>
                <h3>
                  Delivered right away
                </h3>
                <p>
                  Leads go to your CRM, call center or inbox as they come in.
                </p>
              </div>
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-map-location-dot" />
                  </svg>
                </div>
                <h3>
                  Your states, your lines
                </h3>
                <p>
                  Tell us where you are licensed and which coverage you sell.
                </p>
              </div>
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-scale-balanced" />
                  </svg>
                </div>
                <h3>
                  Clear consent
                </h3>
                <p>
                  Plain-language disclosures and TCPA-aware opt-in on every form.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section id="services">
          <div className="wrap">
            <div className="head">
              <h2>
                Our services
              </h2>
              <p className="lead">
                Pick a category to see every service we generate leads for. Each one has its own page with coverage details and answers to common questions.
              </p>
            </div>
            <div className="tabs" role="tablist">
              <button className="tab" role="tab" data-tab="personal" aria-selected="true">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-user" />
                </svg>
                {" Personal"}
              </button>
              <button className="tab" role="tab" data-tab="business" aria-selected="false">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-briefcase" />
                </svg>
                {" Business"}
              </button>
              <button className="tab" role="tab" data-tab="special" aria-selected="false">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-star" />
                </svg>
                {" Special"}
              </button>
              <button className="tab" role="tab" data-tab="finance" aria-selected="false">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-coins" />
                </svg>
                {" Finance"}
              </button>
            </div>
            <div className="panel on" id="personal" role="tabpanel">
              <div className="grid g3">
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-car-side" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/auto-insurance.html">
                      Auto Insurance
                    </Link>
                  </h3>
                  <p>
                    Car, motorcycle, RV and boat coverage.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Auto%20Insurance" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Auto%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Auto%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-house" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/home-insurance.html">
                      Home Insurance
                    </Link>
                  </h3>
                  <p>
                    Homeowners, renters and condo coverage.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Home%20Insurance" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Home%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Home%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-heart-pulse" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/health-insurance.html">
                      Health Insurance
                    </Link>
                  </h3>
                  <p>
                    Individual, family, Medicare and Medicaid options.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Health%20Insurance" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Health%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Health%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-hand-holding-heart" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/life-insurance.html">
                      Life Insurance
                    </Link>
                  </h3>
                  <p>
                    Term, whole life and final expense plans.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Life%20Insurance" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Life%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Life%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-tooth" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/dental-vision.html">
                      Dental &amp; Vision
                    </Link>
                  </h3>
                  <p>
                    Coverage for teeth, eyes and routine care.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Dental%20%26%20Vision" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Dental%20%26%20Vision&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Dental%20%26%20Vision.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-plane" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/travel-insurance.html">
                      Travel Insurance
                    </Link>
                  </h3>
                  <p>
                    Protection for trips at home and abroad.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Travel%20Insurance" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Travel%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Travel%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-paw" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/pet-insurance.html">
                      Pet Insurance
                    </Link>
                  </h3>
                  <p>
                    Help with vet bills for dogs and cats.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Pet%20Insurance" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Pet%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Pet%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-umbrella" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/umbrella-insurance.html">
                      Umbrella Insurance
                    </Link>
                  </h3>
                  <p>
                    Extra liability protection above your other policies.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Umbrella%20Insurance" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Umbrella%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Umbrella%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-house-flood-water" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/flood-earthquake-insurance.html">
                      Flood &amp; Earthquake Insurance
                    </Link>
                  </h3>
                  <p>
                    Coverage for damage standard home policies leave out.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Flood%20%26%20Earthquake%20Insurance" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Flood%20%26%20Earthquake%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Flood%20%26%20Earthquake%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
              </div>
            </div>
            <div className="panel" id="business" role="tabpanel">
              <div className="grid g3">
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-scale-balanced" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/general-liability.html">
                      General Liability
                    </Link>
                  </h3>
                  <p>
                    Protection from customer injury and property damage claims.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20General%20Liability" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20General%20Liability&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20General%20Liability.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-truck" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/commercial-auto.html">
                      Commercial Auto
                    </Link>
                  </h3>
                  <p>
                    Coverage for vehicles used in your business.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Commercial%20Auto" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Commercial%20Auto&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Commercial%20Auto.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-helmet-safety" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/workers-compensation.html">
                      Workers’ Compensation
                    </Link>
                  </h3>
                  <p>
                    Medical and wage benefits for injured employees.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Workers%E2%80%99%20Compensation" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Workers%E2%80%99%20Compensation&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Workers%E2%80%99%20Compensation.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-briefcase" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/professional-liability.html">
                      Professional Liability (E&amp;O)
                    </Link>
                  </h3>
                  <p>
                    Protection against claims of mistakes in your work.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Professional%20Liability%20%28E%26O%29" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Professional%20Liability%20%28E%26O%29&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Professional%20Liability%20%28E%26O%29.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-store" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/business-owners-policy.html">
                      Business Owner’s Policy (BOP)
                    </Link>
                  </h3>
                  <p>
                    General liability and property cover in one bundle.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Business%20Owner%E2%80%99s%20Policy%20%28BOP%29" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Business%20Owner%E2%80%99s%20Policy%20%28BOP%29&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Business%20Owner%E2%80%99s%20Policy%20%28BOP%29.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-shield-virus" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/cyber-insurance.html">
                      Cyber Insurance
                    </Link>
                  </h3>
                  <p>
                    Protection against data breaches and online attacks.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Cyber%20Insurance" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Cyber%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Cyber%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-building" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/commercial-property.html">
                      Commercial Property
                    </Link>
                  </h3>
                  <p>
                    Coverage for your building, equipment and stock.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Commercial%20Property" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Commercial%20Property&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Commercial%20Property.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-people-group" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/group-health.html">
                      Group Health
                    </Link>
                  </h3>
                  <p>
                    Health benefits for your employees.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Group%20Health" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Group%20Health&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Group%20Health.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
              </div>
            </div>
            <div className="panel" id="special" role="tabpanel">
              <div className="grid g3">
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-wheelchair" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/disability-insurance.html">
                      Disability Insurance
                    </Link>
                  </h3>
                  <p>
                    Income protection if you cannot work.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Disability%20Insurance" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Disability%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Disability%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-bed-pulse" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/long-term-care.html">
                      Long-Term Care
                    </Link>
                  </h3>
                  <p>
                    Coverage for extended care at home or in a facility.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Long-Term%20Care" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Long-Term%20Care&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Long-Term%20Care.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-piggy-bank" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/annuities-retirement.html">
                      Annuities / Retirement
                    </Link>
                  </h3>
                  <p>
                    Steady income for retirement.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Annuities%20/%20Retirement" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Annuities%20/%20Retirement&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Annuities%20/%20Retirement.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-truck-moving" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/trucking-insurance.html">
                      Trucking Insurance
                    </Link>
                  </h3>
                  <p>
                    Coverage for owner-operators and fleets.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Trucking%20Insurance" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Trucking%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Trucking%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
              </div>
            </div>
            <div className="panel" id="finance" role="tabpanel">
              <div className="grid g3">
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-money-bill-wave" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/personal-loans.html">
                      Personal Loans
                    </Link>
                  </h3>
                  <p>
                    Compare personal loan offers.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Personal%20Loans" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Personal%20Loans&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Personal%20Loans.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-file-invoice-dollar" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/debt-relief.html">
                      Debt Relief
                    </Link>
                  </h3>
                  <p>
                    Options to manage and reduce unsecured debt.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Debt%20Relief" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Debt%20Relief&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Debt%20Relief.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-credit-card" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/credit-repair.html">
                      Credit Repair
                    </Link>
                  </h3>
                  <p>
                    Help correcting errors and rebuilding credit.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Credit%20Repair" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Credit%20Repair&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Credit%20Repair.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-key" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/mortgage.html">
                      Mortgage
                    </Link>
                  </h3>
                  <p>
                    Purchase and refinance loan options.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Mortgage" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Mortgage&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Mortgage.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
                <article className="card sc rv">
                  <div className="ico">
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-calculator" />
                    </svg>
                  </div>
                  <h3>
                    <Link to="/tax-help.html">
                      Tax Help
                    </Link>
                  </h3>
                  <p>
                    Preparation, back taxes and IRS support.
                  </p>
                  <div className="act">
                    <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Tax%20Help" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-whatsapp" />
                      </svg>
                      {" WhatsApp"}
                    </a>
                    <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Tax%20Help&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Tax%20Help.%0A%0AName%3A%0APhone%3A%0A"}>
                      <svg className="i" aria-hidden="true">
                        <use href="#solid-envelope" />
                      </svg>
                      {" Email"}
                    </a>
                  </div>
                </article>
              </div>
            </div>
          </div>
        </section>
        <section className="alt">
          <div className="wrap">
            <div className="head c">
              <h2>
                How a campaign runs
              </h2>
              <p className="lead">
                A simple path from your brief to leads in your system.
              </p>
            </div>
            <div className="grid g4 steps">
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-clipboard-list" />
                  </svg>
                </div>
                <h3>
                  Brief
                </h3>
                <p>
                  You share your offer, target states, caps and quality rules.
                </p>
              </div>
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-bullhorn" />
                  </svg>
                </div>
                <h3>
                  Launch
                </h3>
                <p>
                  We build compliant creatives and landing pages and start traffic.
                </p>
              </div>
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-filter" />
                  </svg>
                </div>
                <h3>
                  Verify
                </h3>
                <p>
                  Every lead is validated and carries proof of consent.
                </p>
              </div>
              <div className="card rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-chart-line" />
                  </svg>
                </div>
                <h3>
                  Optimize
                </h3>
                <p>
                  We review quality and cost daily and scale what works.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section id="reach">
          <div className="wrap">
            <div className="mapbox">
              <div className="head c" style={{marginBottom:"10px"}}>
                <h2>
                  Connected across the United States
                </h2>
                <p className="lead">
                  From our office in Michigan to partners and customers nationwide, leads move from state to state in real time.
                </p>
              </div>
              <svg className="usa" viewBox="0 0 960 608" role="img" aria-label="Map of the United States with connections between states">
                <path className="dots" d="M75 30h0M85 30h0M95 30h0M105 30h0M115 30h0M125 30h0M135 30h0M145 30h0M155 30h0M165 30h0M70 40h0M80 40h0M90 40h0M100 40h0M110 40h0M120 40h0M130 40h0M140 40h0M150 40h0M160 40h0M170 40h0M180 40h0M190 40h0M200 40h0M210 40h0M220 40h0M230 40h0M240 40h0M75 50h0M85 50h0M95 50h0M105 50h0M115 50h0M125 50h0M135 50h0M145 50h0M155 50h0M165 50h0M175 50h0M185 50h0M195 50h0M205 50h0M215 50h0M225 50h0M235 50h0M245 50h0M255 50h0M265 50h0M275 50h0M285 50h0M295 50h0M305 50h0M315 50h0M70 60h0M80 60h0M90 60h0M100 60h0M110 60h0M120 60h0M130 60h0M140 60h0M150 60h0M160 60h0M170 60h0M180 60h0M190 60h0M200 60h0M210 60h0M220 60h0M230 60h0M240 60h0M250 60h0M260 60h0M270 60h0M280 60h0M290 60h0M300 60h0M310 60h0M320 60h0M330 60h0M340 60h0M350 60h0M360 60h0M370 60h0M380 60h0M390 60h0M890 60h0M900 60h0M910 60h0M65 70h0M75 70h0M85 70h0M95 70h0M105 70h0M115 70h0M125 70h0M135 70h0M145 70h0M155 70h0M165 70h0M175 70h0M185 70h0M195 70h0M205 70h0M215 70h0M225 70h0M235 70h0M245 70h0M255 70h0M265 70h0M275 70h0M285 70h0M295 70h0M305 70h0M315 70h0M325 70h0M335 70h0M345 70h0M355 70h0M365 70h0M375 70h0M385 70h0M395 70h0M405 70h0M415 70h0M425 70h0M435 70h0M445 70h0M455 70h0M885 70h0M895 70h0M905 70h0M915 70h0M70 80h0M80 80h0M90 80h0M100 80h0M110 80h0M120 80h0M130 80h0M140 80h0M150 80h0M160 80h0M170 80h0M180 80h0M190 80h0M200 80h0M210 80h0M220 80h0M230 80h0M240 80h0M250 80h0M260 80h0M270 80h0M280 80h0M290 80h0M300 80h0M310 80h0M320 80h0M330 80h0M340 80h0M350 80h0M360 80h0M370 80h0M380 80h0M390 80h0M400 80h0M410 80h0M420 80h0M430 80h0M440 80h0M450 80h0M460 80h0M470 80h0M480 80h0M490 80h0M500 80h0M890 80h0M900 80h0M910 80h0M920 80h0M65 90h0M75 90h0M85 90h0M95 90h0M105 90h0M115 90h0M125 90h0M135 90h0M145 90h0M155 90h0M165 90h0M175 90h0M185 90h0M195 90h0M205 90h0M215 90h0M225 90h0M235 90h0M245 90h0M255 90h0M265 90h0M275 90h0M285 90h0M295 90h0M305 90h0M315 90h0M325 90h0M335 90h0M345 90h0M355 90h0M365 90h0M375 90h0M385 90h0M395 90h0M405 90h0M415 90h0M425 90h0M435 90h0M445 90h0M455 90h0M465 90h0M475 90h0M485 90h0M495 90h0M505 90h0M515 90h0M525 90h0M535 90h0M545 90h0M885 90h0M895 90h0M905 90h0M915 90h0M925 90h0M60 100h0M70 100h0M80 100h0M90 100h0M100 100h0M110 100h0M120 100h0M130 100h0M140 100h0M150 100h0M160 100h0M170 100h0M180 100h0M190 100h0M200 100h0M210 100h0M220 100h0M230 100h0M240 100h0M250 100h0M260 100h0M270 100h0M280 100h0M290 100h0M300 100h0M310 100h0M320 100h0M330 100h0M340 100h0M350 100h0M360 100h0M370 100h0M380 100h0M390 100h0M400 100h0M410 100h0M420 100h0M430 100h0M440 100h0M450 100h0M460 100h0M470 100h0M480 100h0M490 100h0M500 100h0M510 100h0M520 100h0M530 100h0M540 100h0M550 100h0M560 100h0M570 100h0M880 100h0M890 100h0M900 100h0M910 100h0M920 100h0M930 100h0M55 110h0M65 110h0M75 110h0M85 110h0M95 110h0M105 110h0M115 110h0M125 110h0M135 110h0M145 110h0M155 110h0M165 110h0M175 110h0M185 110h0M195 110h0M205 110h0M215 110h0M225 110h0M235 110h0M245 110h0M255 110h0M265 110h0M275 110h0M285 110h0M295 110h0M305 110h0M315 110h0M325 110h0M335 110h0M345 110h0M355 110h0M365 110h0M375 110h0M385 110h0M395 110h0M405 110h0M415 110h0M425 110h0M435 110h0M445 110h0M455 110h0M465 110h0M475 110h0M485 110h0M495 110h0M505 110h0M515 110h0M525 110h0M535 110h0M545 110h0M555 110h0M565 110h0M605 110h0M875 110h0M885 110h0M895 110h0M905 110h0M915 110h0M925 110h0M50 120h0M60 120h0M70 120h0M80 120h0M90 120h0M100 120h0M110 120h0M120 120h0M130 120h0M140 120h0M150 120h0M160 120h0M170 120h0M180 120h0M190 120h0M200 120h0M210 120h0M220 120h0M230 120h0M240 120h0M250 120h0M260 120h0M270 120h0M280 120h0M290 120h0M300 120h0M310 120h0M320 120h0M330 120h0M340 120h0M350 120h0M360 120h0M370 120h0M380 120h0M390 120h0M400 120h0M410 120h0M420 120h0M430 120h0M440 120h0M450 120h0M460 120h0M470 120h0M480 120h0M490 120h0M500 120h0M510 120h0M520 120h0M530 120h0M540 120h0M550 120h0M570 120h0M590 120h0M600 120h0M610 120h0M640 120h0M650 120h0M660 120h0M850 120h0M860 120h0M870 120h0M880 120h0M890 120h0M900 120h0M910 120h0M920 120h0M45 130h0M55 130h0M65 130h0M75 130h0M85 130h0M95 130h0M105 130h0M115 130h0M125 130h0M135 130h0M145 130h0M155 130h0M165 130h0M175 130h0M185 130h0M195 130h0M205 130h0M215 130h0M225 130h0M235 130h0M245 130h0M255 130h0M265 130h0M275 130h0M285 130h0M295 130h0M305 130h0M315 130h0M325 130h0M335 130h0M345 130h0M355 130h0M365 130h0M375 130h0M385 130h0M395 130h0M405 130h0M415 130h0M425 130h0M435 130h0M445 130h0M455 130h0M465 130h0M475 130h0M485 130h0M495 130h0M505 130h0M515 130h0M525 130h0M535 130h0M545 130h0M555 130h0M565 130h0M575 130h0M585 130h0M595 130h0M605 130h0M615 130h0M625 130h0M635 130h0M645 130h0M655 130h0M665 130h0M675 130h0M825 130h0M835 130h0M845 130h0M855 130h0M865 130h0M875 130h0M885 130h0M895 130h0M905 130h0M40 140h0M50 140h0M60 140h0M70 140h0M80 140h0M90 140h0M100 140h0M110 140h0M120 140h0M130 140h0M140 140h0M150 140h0M160 140h0M170 140h0M180 140h0M190 140h0M200 140h0M210 140h0M220 140h0M230 140h0M240 140h0M250 140h0M260 140h0M270 140h0M280 140h0M290 140h0M300 140h0M310 140h0M320 140h0M330 140h0M340 140h0M350 140h0M360 140h0M370 140h0M380 140h0M390 140h0M400 140h0M410 140h0M420 140h0M430 140h0M440 140h0M450 140h0M460 140h0M470 140h0M480 140h0M490 140h0M500 140h0M510 140h0M520 140h0M530 140h0M540 140h0M550 140h0M560 140h0M570 140h0M580 140h0M590 140h0M600 140h0M610 140h0M620 140h0M630 140h0M660 140h0M670 140h0M680 140h0M690 140h0M820 140h0M830 140h0M840 140h0M850 140h0M860 140h0M870 140h0M880 140h0M890 140h0M35 150h0M45 150h0M55 150h0M65 150h0M75 150h0M85 150h0M95 150h0M105 150h0M115 150h0M125 150h0M135 150h0M145 150h0M155 150h0M165 150h0M175 150h0M185 150h0M195 150h0M205 150h0M215 150h0M225 150h0M235 150h0M245 150h0M255 150h0M265 150h0M275 150h0M285 150h0M295 150h0M305 150h0M315 150h0M325 150h0M335 150h0M345 150h0M355 150h0M365 150h0M375 150h0M385 150h0M395 150h0M405 150h0M415 150h0M425 150h0M435 150h0M445 150h0M455 150h0M465 150h0M475 150h0M485 150h0M495 150h0M505 150h0M515 150h0M525 150h0M535 150h0M545 150h0M555 150h0M565 150h0M575 150h0M585 150h0M595 150h0M605 150h0M615 150h0M625 150h0M655 150h0M665 150h0M675 150h0M685 150h0M695 150h0M815 150h0M825 150h0M835 150h0M845 150h0M855 150h0M865 150h0M875 150h0M885 150h0M895 150h0M40 160h0M50 160h0M60 160h0M70 160h0M80 160h0M90 160h0M100 160h0M110 160h0M120 160h0M130 160h0M140 160h0M150 160h0M160 160h0M170 160h0M180 160h0M190 160h0M200 160h0M210 160h0M220 160h0M230 160h0M240 160h0M250 160h0M260 160h0M270 160h0M280 160h0M290 160h0M300 160h0M310 160h0M320 160h0M330 160h0M340 160h0M350 160h0M360 160h0M370 160h0M380 160h0M390 160h0M400 160h0M410 160h0M420 160h0M430 160h0M440 160h0M450 160h0M460 160h0M470 160h0M480 160h0M490 160h0M500 160h0M510 160h0M520 160h0M530 160h0M540 160h0M550 160h0M560 160h0M570 160h0M580 160h0M590 160h0M600 160h0M610 160h0M620 160h0M650 160h0M660 160h0M670 160h0M680 160h0M690 160h0M700 160h0M810 160h0M820 160h0M830 160h0M840 160h0M850 160h0M860 160h0M870 160h0M880 160h0M890 160h0M35 170h0M45 170h0M55 170h0M65 170h0M75 170h0M85 170h0M95 170h0M105 170h0M115 170h0M125 170h0M135 170h0M145 170h0M155 170h0M165 170h0M175 170h0M185 170h0M195 170h0M205 170h0M215 170h0M225 170h0M235 170h0M245 170h0M255 170h0M265 170h0M275 170h0M285 170h0M295 170h0M305 170h0M315 170h0M325 170h0M335 170h0M345 170h0M355 170h0M365 170h0M375 170h0M385 170h0M395 170h0M405 170h0M415 170h0M425 170h0M435 170h0M445 170h0M455 170h0M465 170h0M475 170h0M485 170h0M495 170h0M505 170h0M515 170h0M525 170h0M535 170h0M545 170h0M555 170h0M565 170h0M575 170h0M585 170h0M595 170h0M605 170h0M615 170h0M645 170h0M655 170h0M665 170h0M675 170h0M685 170h0M695 170h0M705 170h0M795 170h0M805 170h0M815 170h0M825 170h0M835 170h0M845 170h0M855 170h0M865 170h0M875 170h0M885 170h0M30 180h0M40 180h0M50 180h0M60 180h0M70 180h0M80 180h0M90 180h0M100 180h0M110 180h0M120 180h0M130 180h0M140 180h0M150 180h0M160 180h0M170 180h0M180 180h0M190 180h0M200 180h0M210 180h0M220 180h0M230 180h0M240 180h0M250 180h0M260 180h0M270 180h0M280 180h0M290 180h0M300 180h0M310 180h0M320 180h0M330 180h0M340 180h0M350 180h0M360 180h0M370 180h0M380 180h0M390 180h0M400 180h0M410 180h0M420 180h0M430 180h0M440 180h0M450 180h0M460 180h0M470 180h0M480 180h0M490 180h0M500 180h0M510 180h0M520 180h0M530 180h0M540 180h0M550 180h0M560 180h0M570 180h0M580 180h0M590 180h0M600 180h0M610 180h0M650 180h0M660 180h0M670 180h0M680 180h0M690 180h0M700 180h0M770 180h0M780 180h0M790 180h0M800 180h0M810 180h0M820 180h0M830 180h0M840 180h0M850 180h0M860 180h0M870 180h0M880 180h0M890 180h0M900 180h0M25 190h0M35 190h0M45 190h0M55 190h0M65 190h0M75 190h0M85 190h0M95 190h0M105 190h0M115 190h0M125 190h0M135 190h0M145 190h0M155 190h0M165 190h0M175 190h0M185 190h0M195 190h0M205 190h0M215 190h0M225 190h0M235 190h0M245 190h0M255 190h0M265 190h0M275 190h0M285 190h0M295 190h0M305 190h0M315 190h0M325 190h0M335 190h0M345 190h0M355 190h0M365 190h0M375 190h0M385 190h0M395 190h0M405 190h0M415 190h0M425 190h0M435 190h0M445 190h0M455 190h0M465 190h0M475 190h0M485 190h0M495 190h0M505 190h0M515 190h0M525 190h0M535 190h0M545 190h0M555 190h0M565 190h0M575 190h0M585 190h0M595 190h0M605 190h0M615 190h0M655 190h0M665 190h0M675 190h0M685 190h0M695 190h0M705 190h0M765 190h0M775 190h0M785 190h0M795 190h0M805 190h0M815 190h0M825 190h0M835 190h0M845 190h0M855 190h0M865 190h0M875 190h0M885 190h0M30 200h0M40 200h0M50 200h0M60 200h0M70 200h0M80 200h0M90 200h0M100 200h0M110 200h0M120 200h0M130 200h0M140 200h0M150 200h0M160 200h0M170 200h0M180 200h0M190 200h0M200 200h0M210 200h0M220 200h0M230 200h0M240 200h0M250 200h0M260 200h0M270 200h0M280 200h0M290 200h0M300 200h0M310 200h0M320 200h0M330 200h0M340 200h0M350 200h0M360 200h0M370 200h0M380 200h0M390 200h0M400 200h0M410 200h0M420 200h0M430 200h0M440 200h0M450 200h0M460 200h0M470 200h0M480 200h0M490 200h0M500 200h0M510 200h0M520 200h0M530 200h0M540 200h0M550 200h0M560 200h0M570 200h0M580 200h0M590 200h0M600 200h0M610 200h0M620 200h0M650 200h0M660 200h0M670 200h0M680 200h0M690 200h0M700 200h0M760 200h0M770 200h0M780 200h0M790 200h0M800 200h0M810 200h0M820 200h0M830 200h0M840 200h0M850 200h0M860 200h0M870 200h0M25 210h0M35 210h0M45 210h0M55 210h0M65 210h0M75 210h0M85 210h0M95 210h0M105 210h0M115 210h0M125 210h0M135 210h0M145 210h0M155 210h0M165 210h0M175 210h0M185 210h0M195 210h0M205 210h0M215 210h0M225 210h0M235 210h0M245 210h0M255 210h0M265 210h0M275 210h0M285 210h0M295 210h0M305 210h0M315 210h0M325 210h0M335 210h0M345 210h0M355 210h0M365 210h0M375 210h0M385 210h0M395 210h0M405 210h0M415 210h0M425 210h0M435 210h0M445 210h0M455 210h0M465 210h0M475 210h0M485 210h0M495 210h0M505 210h0M515 210h0M525 210h0M535 210h0M545 210h0M555 210h0M565 210h0M575 210h0M585 210h0M595 210h0M605 210h0M615 210h0M655 210h0M665 210h0M675 210h0M685 210h0M695 210h0M745 210h0M755 210h0M765 210h0M775 210h0M785 210h0M795 210h0M805 210h0M815 210h0M825 210h0M835 210h0M845 210h0M855 210h0M30 220h0M40 220h0M50 220h0M60 220h0M70 220h0M80 220h0M90 220h0M100 220h0M110 220h0M120 220h0M130 220h0M140 220h0M150 220h0M160 220h0M170 220h0M180 220h0M190 220h0M200 220h0M210 220h0M220 220h0M230 220h0M240 220h0M250 220h0M260 220h0M270 220h0M280 220h0M290 220h0M300 220h0M310 220h0M320 220h0M330 220h0M340 220h0M350 220h0M360 220h0M370 220h0M380 220h0M390 220h0M400 220h0M410 220h0M420 220h0M430 220h0M440 220h0M450 220h0M460 220h0M470 220h0M480 220h0M490 220h0M500 220h0M510 220h0M520 220h0M530 220h0M540 220h0M550 220h0M560 220h0M570 220h0M580 220h0M590 220h0M600 220h0M610 220h0M620 220h0M650 220h0M660 220h0M670 220h0M680 220h0M690 220h0M740 220h0M750 220h0M760 220h0M770 220h0M780 220h0M790 220h0M800 220h0M810 220h0M820 220h0M830 220h0M840 220h0M850 220h0M35 230h0M45 230h0M55 230h0M65 230h0M75 230h0M85 230h0M95 230h0M105 230h0M115 230h0M125 230h0M135 230h0M145 230h0M155 230h0M165 230h0M175 230h0M185 230h0M195 230h0M205 230h0M215 230h0M225 230h0M235 230h0M245 230h0M255 230h0M265 230h0M275 230h0M285 230h0M295 230h0M305 230h0M315 230h0M325 230h0M335 230h0M345 230h0M355 230h0M365 230h0M375 230h0M385 230h0M395 230h0M405 230h0M415 230h0M425 230h0M435 230h0M445 230h0M455 230h0M465 230h0M475 230h0M485 230h0M495 230h0M505 230h0M515 230h0M525 230h0M535 230h0M545 230h0M555 230h0M565 230h0M575 230h0M585 230h0M595 230h0M605 230h0M615 230h0M625 230h0M645 230h0M655 230h0M665 230h0M675 230h0M685 230h0M695 230h0M705 230h0M715 230h0M725 230h0M735 230h0M745 230h0M755 230h0M765 230h0M775 230h0M785 230h0M795 230h0M805 230h0M815 230h0M825 230h0M835 230h0M845 230h0M855 230h0M30 240h0M40 240h0M50 240h0M60 240h0M70 240h0M80 240h0M90 240h0M100 240h0M110 240h0M120 240h0M130 240h0M140 240h0M150 240h0M160 240h0M170 240h0M180 240h0M190 240h0M200 240h0M210 240h0M220 240h0M230 240h0M240 240h0M250 240h0M260 240h0M270 240h0M280 240h0M290 240h0M300 240h0M310 240h0M320 240h0M330 240h0M340 240h0M350 240h0M360 240h0M370 240h0M380 240h0M390 240h0M400 240h0M410 240h0M420 240h0M430 240h0M440 240h0M450 240h0M460 240h0M470 240h0M480 240h0M490 240h0M500 240h0M510 240h0M520 240h0M530 240h0M540 240h0M550 240h0M560 240h0M570 240h0M580 240h0M590 240h0M600 240h0M610 240h0M620 240h0M630 240h0M640 240h0M650 240h0M660 240h0M670 240h0M680 240h0M690 240h0M700 240h0M710 240h0M720 240h0M730 240h0M740 240h0M750 240h0M760 240h0M770 240h0M780 240h0M790 240h0M800 240h0M810 240h0M820 240h0M830 240h0M840 240h0M850 240h0M35 250h0M45 250h0M55 250h0M65 250h0M75 250h0M85 250h0M95 250h0M105 250h0M115 250h0M125 250h0M135 250h0M145 250h0M155 250h0M165 250h0M175 250h0M185 250h0M195 250h0M205 250h0M215 250h0M225 250h0M235 250h0M245 250h0M255 250h0M265 250h0M275 250h0M285 250h0M295 250h0M305 250h0M315 250h0M325 250h0M335 250h0M345 250h0M355 250h0M365 250h0M375 250h0M385 250h0M395 250h0M405 250h0M415 250h0M425 250h0M435 250h0M445 250h0M455 250h0M465 250h0M475 250h0M485 250h0M495 250h0M505 250h0M515 250h0M525 250h0M535 250h0M545 250h0M555 250h0M565 250h0M575 250h0M585 250h0M595 250h0M605 250h0M615 250h0M625 250h0M635 250h0M645 250h0M655 250h0M665 250h0M675 250h0M685 250h0M695 250h0M705 250h0M715 250h0M725 250h0M735 250h0M745 250h0M755 250h0M765 250h0M775 250h0M785 250h0M795 250h0M805 250h0M815 250h0M825 250h0M835 250h0M845 250h0M40 260h0M50 260h0M60 260h0M70 260h0M80 260h0M90 260h0M100 260h0M110 260h0M120 260h0M130 260h0M140 260h0M150 260h0M160 260h0M170 260h0M180 260h0M190 260h0M200 260h0M210 260h0M220 260h0M230 260h0M240 260h0M250 260h0M260 260h0M270 260h0M280 260h0M290 260h0M300 260h0M310 260h0M320 260h0M330 260h0M340 260h0M350 260h0M360 260h0M370 260h0M380 260h0M390 260h0M400 260h0M410 260h0M420 260h0M430 260h0M440 260h0M450 260h0M460 260h0M470 260h0M480 260h0M490 260h0M500 260h0M510 260h0M520 260h0M530 260h0M540 260h0M550 260h0M560 260h0M570 260h0M580 260h0M590 260h0M600 260h0M610 260h0M620 260h0M630 260h0M640 260h0M650 260h0M660 260h0M670 260h0M680 260h0M690 260h0M700 260h0M710 260h0M720 260h0M730 260h0M740 260h0M750 260h0M760 260h0M770 260h0M780 260h0M790 260h0M800 260h0M810 260h0M820 260h0M830 260h0M840 260h0M45 270h0M55 270h0M65 270h0M75 270h0M85 270h0M95 270h0M105 270h0M115 270h0M125 270h0M135 270h0M145 270h0M155 270h0M165 270h0M175 270h0M185 270h0M195 270h0M205 270h0M215 270h0M225 270h0M235 270h0M245 270h0M255 270h0M265 270h0M275 270h0M285 270h0M295 270h0M305 270h0M315 270h0M325 270h0M335 270h0M345 270h0M355 270h0M365 270h0M375 270h0M385 270h0M395 270h0M405 270h0M415 270h0M425 270h0M435 270h0M445 270h0M455 270h0M465 270h0M475 270h0M485 270h0M495 270h0M505 270h0M515 270h0M525 270h0M535 270h0M545 270h0M555 270h0M565 270h0M575 270h0M585 270h0M595 270h0M605 270h0M615 270h0M625 270h0M635 270h0M645 270h0M655 270h0M665 270h0M675 270h0M685 270h0M695 270h0M705 270h0M715 270h0M725 270h0M735 270h0M745 270h0M755 270h0M765 270h0M775 270h0M785 270h0M795 270h0M805 270h0M815 270h0M825 270h0M835 270h0M845 270h0M40 280h0M50 280h0M60 280h0M70 280h0M80 280h0M90 280h0M100 280h0M110 280h0M120 280h0M130 280h0M140 280h0M150 280h0M160 280h0M170 280h0M180 280h0M190 280h0M200 280h0M210 280h0M220 280h0M230 280h0M240 280h0M250 280h0M260 280h0M270 280h0M280 280h0M290 280h0M300 280h0M310 280h0M320 280h0M330 280h0M340 280h0M350 280h0M360 280h0M370 280h0M380 280h0M390 280h0M400 280h0M410 280h0M420 280h0M430 280h0M440 280h0M450 280h0M460 280h0M470 280h0M480 280h0M490 280h0M500 280h0M510 280h0M520 280h0M530 280h0M540 280h0M550 280h0M560 280h0M570 280h0M580 280h0M590 280h0M600 280h0M610 280h0M620 280h0M630 280h0M640 280h0M650 280h0M660 280h0M670 280h0M680 280h0M690 280h0M700 280h0M710 280h0M720 280h0M730 280h0M740 280h0M750 280h0M760 280h0M770 280h0M780 280h0M790 280h0M800 280h0M810 280h0M820 280h0M830 280h0M840 280h0M45 290h0M55 290h0M65 290h0M75 290h0M85 290h0M95 290h0M105 290h0M115 290h0M125 290h0M135 290h0M145 290h0M155 290h0M165 290h0M175 290h0M185 290h0M195 290h0M205 290h0M215 290h0M225 290h0M235 290h0M245 290h0M255 290h0M265 290h0M275 290h0M285 290h0M295 290h0M305 290h0M315 290h0M325 290h0M335 290h0M345 290h0M355 290h0M365 290h0M375 290h0M385 290h0M395 290h0M405 290h0M415 290h0M425 290h0M435 290h0M445 290h0M455 290h0M465 290h0M475 290h0M485 290h0M495 290h0M505 290h0M515 290h0M525 290h0M535 290h0M545 290h0M555 290h0M565 290h0M575 290h0M585 290h0M595 290h0M605 290h0M615 290h0M625 290h0M635 290h0M645 290h0M655 290h0M665 290h0M675 290h0M685 290h0M695 290h0M705 290h0M715 290h0M725 290h0M735 290h0M745 290h0M755 290h0M765 290h0M775 290h0M785 290h0M795 290h0M805 290h0M815 290h0M825 290h0M835 290h0M40 300h0M50 300h0M60 300h0M70 300h0M80 300h0M90 300h0M100 300h0M110 300h0M120 300h0M130 300h0M140 300h0M150 300h0M160 300h0M170 300h0M180 300h0M190 300h0M200 300h0M210 300h0M220 300h0M230 300h0M240 300h0M250 300h0M260 300h0M270 300h0M280 300h0M290 300h0M300 300h0M310 300h0M320 300h0M330 300h0M340 300h0M350 300h0M360 300h0M370 300h0M380 300h0M390 300h0M400 300h0M410 300h0M420 300h0M430 300h0M440 300h0M450 300h0M460 300h0M470 300h0M480 300h0M490 300h0M500 300h0M510 300h0M520 300h0M530 300h0M540 300h0M550 300h0M560 300h0M570 300h0M580 300h0M590 300h0M600 300h0M610 300h0M620 300h0M630 300h0M640 300h0M650 300h0M660 300h0M670 300h0M680 300h0M690 300h0M700 300h0M710 300h0M720 300h0M730 300h0M740 300h0M750 300h0M760 300h0M770 300h0M780 300h0M790 300h0M800 300h0M810 300h0M820 300h0M830 300h0M840 300h0M45 310h0M55 310h0M65 310h0M75 310h0M85 310h0M95 310h0M105 310h0M115 310h0M125 310h0M135 310h0M145 310h0M155 310h0M165 310h0M175 310h0M185 310h0M195 310h0M205 310h0M215 310h0M225 310h0M235 310h0M245 310h0M255 310h0M265 310h0M275 310h0M285 310h0M295 310h0M305 310h0M315 310h0M325 310h0M335 310h0M345 310h0M355 310h0M365 310h0M375 310h0M385 310h0M395 310h0M405 310h0M415 310h0M425 310h0M435 310h0M445 310h0M455 310h0M465 310h0M475 310h0M485 310h0M495 310h0M505 310h0M515 310h0M525 310h0M535 310h0M545 310h0M555 310h0M565 310h0M575 310h0M585 310h0M595 310h0M605 310h0M615 310h0M625 310h0M635 310h0M645 310h0M655 310h0M665 310h0M675 310h0M685 310h0M695 310h0M705 310h0M715 310h0M725 310h0M735 310h0M745 310h0M755 310h0M765 310h0M775 310h0M785 310h0M795 310h0M805 310h0M815 310h0M825 310h0M835 310h0M50 320h0M60 320h0M70 320h0M80 320h0M90 320h0M100 320h0M110 320h0M120 320h0M130 320h0M140 320h0M150 320h0M160 320h0M170 320h0M180 320h0M190 320h0M200 320h0M210 320h0M220 320h0M230 320h0M240 320h0M250 320h0M260 320h0M270 320h0M280 320h0M290 320h0M300 320h0M310 320h0M320 320h0M330 320h0M340 320h0M350 320h0M360 320h0M370 320h0M380 320h0M390 320h0M400 320h0M410 320h0M420 320h0M430 320h0M440 320h0M450 320h0M460 320h0M470 320h0M480 320h0M490 320h0M500 320h0M510 320h0M520 320h0M530 320h0M540 320h0M550 320h0M560 320h0M570 320h0M580 320h0M590 320h0M600 320h0M610 320h0M620 320h0M630 320h0M640 320h0M650 320h0M660 320h0M670 320h0M680 320h0M690 320h0M700 320h0M710 320h0M720 320h0M730 320h0M740 320h0M750 320h0M760 320h0M770 320h0M780 320h0M790 320h0M800 320h0M810 320h0M820 320h0M830 320h0M840 320h0M55 330h0M65 330h0M75 330h0M85 330h0M95 330h0M105 330h0M115 330h0M125 330h0M135 330h0M145 330h0M155 330h0M165 330h0M175 330h0M185 330h0M195 330h0M205 330h0M215 330h0M225 330h0M235 330h0M245 330h0M255 330h0M265 330h0M275 330h0M285 330h0M295 330h0M305 330h0M315 330h0M325 330h0M335 330h0M345 330h0M355 330h0M365 330h0M375 330h0M385 330h0M395 330h0M405 330h0M415 330h0M425 330h0M435 330h0M445 330h0M455 330h0M465 330h0M475 330h0M485 330h0M495 330h0M505 330h0M515 330h0M525 330h0M535 330h0M545 330h0M555 330h0M565 330h0M575 330h0M585 330h0M595 330h0M605 330h0M615 330h0M625 330h0M635 330h0M645 330h0M655 330h0M665 330h0M675 330h0M685 330h0M695 330h0M705 330h0M715 330h0M725 330h0M735 330h0M745 330h0M755 330h0M765 330h0M775 330h0M785 330h0M795 330h0M805 330h0M815 330h0M825 330h0M835 330h0M845 330h0M50 340h0M60 340h0M70 340h0M80 340h0M90 340h0M100 340h0M110 340h0M120 340h0M130 340h0M140 340h0M150 340h0M160 340h0M170 340h0M180 340h0M190 340h0M200 340h0M210 340h0M220 340h0M230 340h0M240 340h0M250 340h0M260 340h0M270 340h0M280 340h0M290 340h0M300 340h0M310 340h0M320 340h0M330 340h0M340 340h0M350 340h0M360 340h0M370 340h0M380 340h0M390 340h0M400 340h0M410 340h0M420 340h0M430 340h0M440 340h0M450 340h0M460 340h0M470 340h0M480 340h0M490 340h0M500 340h0M510 340h0M520 340h0M530 340h0M540 340h0M550 340h0M560 340h0M570 340h0M580 340h0M590 340h0M600 340h0M610 340h0M620 340h0M630 340h0M640 340h0M650 340h0M660 340h0M670 340h0M680 340h0M690 340h0M700 340h0M710 340h0M720 340h0M730 340h0M740 340h0M750 340h0M760 340h0M770 340h0M780 340h0M790 340h0M800 340h0M810 340h0M820 340h0M830 340h0M840 340h0M850 340h0M65 350h0M75 350h0M85 350h0M95 350h0M105 350h0M115 350h0M125 350h0M135 350h0M145 350h0M155 350h0M165 350h0M175 350h0M185 350h0M195 350h0M205 350h0M215 350h0M225 350h0M235 350h0M245 350h0M255 350h0M265 350h0M275 350h0M285 350h0M295 350h0M305 350h0M315 350h0M325 350h0M335 350h0M345 350h0M355 350h0M365 350h0M375 350h0M385 350h0M395 350h0M405 350h0M415 350h0M425 350h0M435 350h0M445 350h0M455 350h0M465 350h0M475 350h0M485 350h0M495 350h0M505 350h0M515 350h0M525 350h0M535 350h0M545 350h0M555 350h0M565 350h0M575 350h0M585 350h0M595 350h0M605 350h0M615 350h0M625 350h0M635 350h0M645 350h0M655 350h0M665 350h0M675 350h0M685 350h0M695 350h0M705 350h0M715 350h0M725 350h0M735 350h0M745 350h0M755 350h0M765 350h0M775 350h0M785 350h0M795 350h0M805 350h0M815 350h0M825 350h0M835 350h0M845 350h0M80 360h0M90 360h0M100 360h0M110 360h0M120 360h0M130 360h0M140 360h0M150 360h0M160 360h0M170 360h0M180 360h0M190 360h0M200 360h0M210 360h0M220 360h0M230 360h0M240 360h0M250 360h0M260 360h0M270 360h0M280 360h0M290 360h0M300 360h0M310 360h0M320 360h0M330 360h0M340 360h0M350 360h0M360 360h0M370 360h0M380 360h0M390 360h0M400 360h0M410 360h0M420 360h0M430 360h0M440 360h0M450 360h0M460 360h0M470 360h0M480 360h0M490 360h0M500 360h0M510 360h0M520 360h0M530 360h0M540 360h0M550 360h0M560 360h0M570 360h0M580 360h0M590 360h0M600 360h0M610 360h0M620 360h0M630 360h0M640 360h0M650 360h0M660 360h0M670 360h0M680 360h0M690 360h0M700 360h0M710 360h0M720 360h0M730 360h0M740 360h0M750 360h0M760 360h0M770 360h0M780 360h0M790 360h0M800 360h0M810 360h0M820 360h0M830 360h0M840 360h0M95 370h0M105 370h0M115 370h0M125 370h0M135 370h0M145 370h0M155 370h0M165 370h0M175 370h0M185 370h0M195 370h0M205 370h0M215 370h0M225 370h0M235 370h0M245 370h0M255 370h0M265 370h0M275 370h0M285 370h0M295 370h0M305 370h0M315 370h0M325 370h0M335 370h0M345 370h0M355 370h0M365 370h0M375 370h0M385 370h0M395 370h0M405 370h0M415 370h0M425 370h0M435 370h0M445 370h0M455 370h0M465 370h0M475 370h0M485 370h0M495 370h0M505 370h0M515 370h0M525 370h0M535 370h0M545 370h0M555 370h0M565 370h0M575 370h0M585 370h0M595 370h0M605 370h0M615 370h0M625 370h0M635 370h0M645 370h0M655 370h0M665 370h0M675 370h0M685 370h0M695 370h0M705 370h0M715 370h0M725 370h0M735 370h0M745 370h0M755 370h0M765 370h0M775 370h0M785 370h0M795 370h0M805 370h0M815 370h0M825 370h0M100 380h0M110 380h0M120 380h0M130 380h0M140 380h0M150 380h0M160 380h0M170 380h0M180 380h0M190 380h0M200 380h0M210 380h0M220 380h0M230 380h0M240 380h0M250 380h0M260 380h0M270 380h0M280 380h0M290 380h0M300 380h0M310 380h0M320 380h0M330 380h0M340 380h0M350 380h0M360 380h0M370 380h0M380 380h0M390 380h0M400 380h0M410 380h0M420 380h0M430 380h0M440 380h0M450 380h0M460 380h0M470 380h0M480 380h0M490 380h0M500 380h0M510 380h0M520 380h0M530 380h0M540 380h0M550 380h0M560 380h0M570 380h0M580 380h0M590 380h0M600 380h0M610 380h0M620 380h0M630 380h0M640 380h0M650 380h0M660 380h0M670 380h0M680 380h0M690 380h0M700 380h0M710 380h0M720 380h0M730 380h0M740 380h0M750 380h0M760 380h0M770 380h0M780 380h0M790 380h0M800 380h0M810 380h0M820 380h0M105 390h0M115 390h0M125 390h0M135 390h0M145 390h0M155 390h0M165 390h0M175 390h0M185 390h0M195 390h0M205 390h0M215 390h0M225 390h0M235 390h0M245 390h0M255 390h0M265 390h0M275 390h0M285 390h0M295 390h0M305 390h0M315 390h0M325 390h0M335 390h0M345 390h0M355 390h0M365 390h0M375 390h0M385 390h0M395 390h0M405 390h0M415 390h0M425 390h0M435 390h0M445 390h0M455 390h0M465 390h0M475 390h0M485 390h0M495 390h0M505 390h0M515 390h0M525 390h0M535 390h0M545 390h0M555 390h0M565 390h0M575 390h0M585 390h0M595 390h0M605 390h0M615 390h0M625 390h0M635 390h0M645 390h0M655 390h0M665 390h0M675 390h0M685 390h0M695 390h0M705 390h0M715 390h0M725 390h0M735 390h0M745 390h0M755 390h0M765 390h0M775 390h0M785 390h0M795 390h0M805 390h0M100 400h0M110 400h0M120 400h0M130 400h0M140 400h0M150 400h0M160 400h0M170 400h0M180 400h0M190 400h0M200 400h0M210 400h0M220 400h0M230 400h0M240 400h0M250 400h0M260 400h0M270 400h0M280 400h0M290 400h0M300 400h0M310 400h0M320 400h0M330 400h0M340 400h0M350 400h0M360 400h0M370 400h0M380 400h0M390 400h0M400 400h0M410 400h0M420 400h0M430 400h0M440 400h0M450 400h0M460 400h0M470 400h0M480 400h0M490 400h0M500 400h0M510 400h0M520 400h0M530 400h0M540 400h0M550 400h0M560 400h0M570 400h0M580 400h0M590 400h0M600 400h0M610 400h0M620 400h0M630 400h0M640 400h0M650 400h0M660 400h0M670 400h0M680 400h0M690 400h0M700 400h0M710 400h0M720 400h0M730 400h0M740 400h0M750 400h0M760 400h0M770 400h0M780 400h0M790 400h0M800 400h0M145 410h0M155 410h0M165 410h0M175 410h0M185 410h0M195 410h0M205 410h0M215 410h0M225 410h0M235 410h0M245 410h0M255 410h0M265 410h0M275 410h0M285 410h0M295 410h0M305 410h0M315 410h0M325 410h0M335 410h0M345 410h0M355 410h0M365 410h0M375 410h0M385 410h0M395 410h0M405 410h0M415 410h0M425 410h0M435 410h0M445 410h0M455 410h0M465 410h0M475 410h0M485 410h0M495 410h0M505 410h0M515 410h0M525 410h0M535 410h0M545 410h0M555 410h0M565 410h0M575 410h0M585 410h0M595 410h0M605 410h0M615 410h0M625 410h0M635 410h0M645 410h0M655 410h0M665 410h0M675 410h0M685 410h0M695 410h0M705 410h0M715 410h0M725 410h0M735 410h0M745 410h0M755 410h0M765 410h0M775 410h0M785 410h0M160 420h0M170 420h0M180 420h0M190 420h0M200 420h0M210 420h0M220 420h0M230 420h0M240 420h0M250 420h0M260 420h0M270 420h0M280 420h0M290 420h0M300 420h0M310 420h0M320 420h0M330 420h0M340 420h0M350 420h0M360 420h0M370 420h0M380 420h0M390 420h0M400 420h0M410 420h0M420 420h0M430 420h0M440 420h0M450 420h0M460 420h0M470 420h0M480 420h0M490 420h0M500 420h0M510 420h0M520 420h0M530 420h0M540 420h0M550 420h0M560 420h0M570 420h0M580 420h0M590 420h0M600 420h0M610 420h0M620 420h0M630 420h0M640 420h0M650 420h0M660 420h0M670 420h0M680 420h0M690 420h0M700 420h0M710 420h0M720 420h0M730 420h0M740 420h0M750 420h0M760 420h0M770 420h0M780 420h0M175 430h0M185 430h0M195 430h0M205 430h0M215 430h0M225 430h0M235 430h0M245 430h0M255 430h0M265 430h0M275 430h0M285 430h0M295 430h0M305 430h0M315 430h0M325 430h0M335 430h0M345 430h0M355 430h0M365 430h0M375 430h0M385 430h0M395 430h0M405 430h0M415 430h0M425 430h0M435 430h0M445 430h0M455 430h0M465 430h0M475 430h0M485 430h0M495 430h0M505 430h0M515 430h0M525 430h0M535 430h0M545 430h0M555 430h0M565 430h0M575 430h0M585 430h0M595 430h0M605 430h0M615 430h0M625 430h0M635 430h0M645 430h0M655 430h0M665 430h0M675 430h0M685 430h0M695 430h0M705 430h0M715 430h0M725 430h0M735 430h0M745 430h0M755 430h0M765 430h0M775 430h0M200 440h0M210 440h0M220 440h0M230 440h0M240 440h0M250 440h0M260 440h0M270 440h0M280 440h0M290 440h0M300 440h0M310 440h0M320 440h0M330 440h0M340 440h0M350 440h0M360 440h0M370 440h0M380 440h0M390 440h0M400 440h0M410 440h0M420 440h0M430 440h0M440 440h0M450 440h0M460 440h0M470 440h0M480 440h0M490 440h0M500 440h0M510 440h0M520 440h0M530 440h0M540 440h0M550 440h0M560 440h0M570 440h0M580 440h0M590 440h0M600 440h0M610 440h0M620 440h0M630 440h0M640 440h0M650 440h0M660 440h0M670 440h0M680 440h0M690 440h0M700 440h0M710 440h0M720 440h0M730 440h0M740 440h0M750 440h0M760 440h0M770 440h0M225 450h0M235 450h0M245 450h0M255 450h0M295 450h0M305 450h0M315 450h0M325 450h0M335 450h0M345 450h0M355 450h0M365 450h0M375 450h0M385 450h0M395 450h0M405 450h0M415 450h0M425 450h0M435 450h0M445 450h0M455 450h0M465 450h0M475 450h0M485 450h0M495 450h0M505 450h0M515 450h0M525 450h0M535 450h0M545 450h0M555 450h0M565 450h0M575 450h0M585 450h0M595 450h0M605 450h0M615 450h0M625 450h0M635 450h0M645 450h0M655 450h0M665 450h0M675 450h0M685 450h0M695 450h0M705 450h0M715 450h0M725 450h0M735 450h0M745 450h0M755 450h0M765 450h0M310 460h0M320 460h0M330 460h0M340 460h0M350 460h0M360 460h0M370 460h0M380 460h0M390 460h0M400 460h0M410 460h0M420 460h0M430 460h0M440 460h0M450 460h0M460 460h0M470 460h0M480 460h0M490 460h0M500 460h0M510 460h0M520 460h0M530 460h0M540 460h0M550 460h0M560 460h0M570 460h0M580 460h0M590 460h0M600 460h0M610 460h0M620 460h0M630 460h0M640 460h0M650 460h0M660 460h0M670 460h0M680 460h0M690 460h0M700 460h0M710 460h0M720 460h0M730 460h0M740 460h0M750 460h0M760 460h0M315 470h0M325 470h0M335 470h0M345 470h0M355 470h0M365 470h0M375 470h0M385 470h0M395 470h0M405 470h0M415 470h0M425 470h0M435 470h0M445 470h0M455 470h0M465 470h0M475 470h0M485 470h0M495 470h0M505 470h0M515 470h0M525 470h0M535 470h0M545 470h0M555 470h0M565 470h0M575 470h0M585 470h0M595 470h0M605 470h0M615 470h0M625 470h0M635 470h0M645 470h0M655 470h0M665 470h0M675 470h0M685 470h0M695 470h0M705 470h0M715 470h0M725 470h0M735 470h0M745 470h0M755 470h0M765 470h0M330 480h0M340 480h0M350 480h0M360 480h0M370 480h0M380 480h0M390 480h0M400 480h0M410 480h0M420 480h0M430 480h0M440 480h0M450 480h0M460 480h0M470 480h0M480 480h0M490 480h0M500 480h0M510 480h0M520 480h0M530 480h0M540 480h0M550 480h0M560 480h0M570 480h0M580 480h0M590 480h0M600 480h0M610 480h0M620 480h0M630 480h0M640 480h0M650 480h0M660 480h0M670 480h0M680 480h0M690 480h0M700 480h0M710 480h0M720 480h0M730 480h0M740 480h0M750 480h0M760 480h0M770 480h0M325 490h0M335 490h0M345 490h0M355 490h0M365 490h0M375 490h0M385 490h0M395 490h0M405 490h0M415 490h0M425 490h0M435 490h0M445 490h0M455 490h0M465 490h0M475 490h0M485 490h0M495 490h0M505 490h0M515 490h0M525 490h0M535 490h0M545 490h0M555 490h0M565 490h0M575 490h0M585 490h0M595 490h0M605 490h0M615 490h0M695 490h0M705 490h0M715 490h0M735 490h0M745 490h0M755 490h0M765 490h0M775 490h0M330 500h0M340 500h0M350 500h0M360 500h0M380 500h0M390 500h0M400 500h0M410 500h0M420 500h0M430 500h0M440 500h0M450 500h0M460 500h0M470 500h0M480 500h0M490 500h0M500 500h0M510 500h0M520 500h0M530 500h0M540 500h0M550 500h0M560 500h0M570 500h0M580 500h0M590 500h0M600 500h0M610 500h0M620 500h0M740 500h0M750 500h0M760 500h0M770 500h0M780 500h0M345 510h0M355 510h0M395 510h0M405 510h0M415 510h0M425 510h0M435 510h0M445 510h0M455 510h0M465 510h0M475 510h0M485 510h0M495 510h0M505 510h0M515 510h0M525 510h0M585 510h0M595 510h0M605 510h0M615 510h0M755 510h0M765 510h0M775 510h0M785 510h0M400 520h0M410 520h0M420 520h0M430 520h0M440 520h0M450 520h0M460 520h0M470 520h0M480 520h0M490 520h0M500 520h0M750 520h0M760 520h0M770 520h0M780 520h0M790 520h0M405 530h0M415 530h0M425 530h0M435 530h0M445 530h0M455 530h0M465 530h0M475 530h0M485 530h0M755 530h0M765 530h0M775 530h0M785 530h0M795 530h0M420 540h0M430 540h0M440 540h0M450 540h0M460 540h0M470 540h0M760 540h0M770 540h0M780 540h0M790 540h0M800 540h0M425 550h0M435 550h0M445 550h0M455 550h0M465 550h0M765 550h0M775 550h0M785 550h0M795 550h0M805 550h0M430 560h0M440 560h0M450 560h0M460 560h0M780 560h0M790 560h0M800 560h0M435 570h0M445 570h0M455 570h0M785 570h0M795 570h0M805 570h0M440 580h0M450 580h0M460 580h0M790 580h0M800 580h0" />
                <path className="arc" d="M698.3 214.0 Q443.0 12.9 122.3 65.3" />
                <path className="arc" d="M698.3 214.0 Q367.6 118.5 73.8 297.7" />
                <path className="arc" d="M698.3 214.0 Q415.0 188.7 204.9 380.4" />
                <path className="arc" d="M698.3 214.0 Q496.1 170.6 327.5 290.3" />
                <path className="arc" d="M698.3 214.0 Q506.5 282.5 427.5 470.1" />
                <path className="arc" d="M698.3 214.0 Q623.2 137.7 516.3 141.6" />
                <path className="arc" d="M698.3 214.0 Q638.8 222.4 604.8 271.9" />
                <path className="arc" d="M698.3 214.0 Q749.7 168.4 818.1 175.6" />
                <path className="arc" d="M698.3 214.0 Q767.8 264.8 777.3 350.4" />
                <path className="arc" d="M698.3 214.0 Q757.4 313.5 723.9 424.3" />
                <path className="arc" d="M698.3 214.0 Q802.7 352.7 770.9 523.5" />
                <path className="arc" d="M73.8 297.7 Q288.5 306.1 427.5 470.1" />
                <path className="arc" d="M427.5 470.1 Q610.9 421.2 770.9 523.5" />
                <path className="arc" d="M122.3 65.3 Q274.4 132.7 327.5 290.3" />
                <path className="arc" d="M818.1 175.6 Q718.0 339.1 770.9 523.5" />
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="3.0s" begin="0.0s" repeatCount="indefinite" path="M698.3 214.0 Q443.0 12.9 122.3 65.3" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="3.0s" begin="0.0s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="3.7s" begin="0.5s" repeatCount="indefinite" path="M698.3 214.0 Q367.6 118.5 73.8 297.7" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="3.7s" begin="0.5s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="4.4s" begin="0.9s" repeatCount="indefinite" path="M698.3 214.0 Q415.0 188.7 204.9 380.4" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="4.4s" begin="0.9s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="5.1s" begin="1.4s" repeatCount="indefinite" path="M698.3 214.0 Q496.1 170.6 327.5 290.3" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="5.1s" begin="1.4s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="3.0s" begin="1.8s" repeatCount="indefinite" path="M698.3 214.0 Q506.5 282.5 427.5 470.1" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="3.0s" begin="1.8s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="3.7s" begin="2.2s" repeatCount="indefinite" path="M698.3 214.0 Q623.2 137.7 516.3 141.6" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="3.7s" begin="2.2s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="4.4s" begin="2.7s" repeatCount="indefinite" path="M698.3 214.0 Q638.8 222.4 604.8 271.9" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="4.4s" begin="2.7s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="5.1s" begin="0.1s" repeatCount="indefinite" path="M698.3 214.0 Q749.7 168.4 818.1 175.6" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="5.1s" begin="0.1s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="3.0s" begin="0.6s" repeatCount="indefinite" path="M698.3 214.0 Q767.8 264.8 777.3 350.4" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="3.0s" begin="0.6s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="3.7s" begin="1.0s" repeatCount="indefinite" path="M698.3 214.0 Q757.4 313.5 723.9 424.3" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="3.7s" begin="1.0s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="4.4s" begin="1.5s" repeatCount="indefinite" path="M698.3 214.0 Q802.7 352.7 770.9 523.5" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="4.4s" begin="1.5s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="5.1s" begin="2.0s" repeatCount="indefinite" path="M73.8 297.7 Q288.5 306.1 427.5 470.1" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="5.1s" begin="2.0s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="3.0s" begin="2.4s" repeatCount="indefinite" path="M427.5 470.1 Q610.9 421.2 770.9 523.5" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="3.0s" begin="2.4s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="3.7s" begin="2.9s" repeatCount="indefinite" path="M122.3 65.3 Q274.4 132.7 327.5 290.3" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="3.7s" begin="2.9s" repeatCount="indefinite" />
                </circle>
                <circle r="3.8" fill="#ffb020" opacity="0">
                  <animateMotion dur="4.4s" begin="0.3s" repeatCount="indefinite" path="M818.1 175.6 Q718.0 339.1 770.9 523.5" />
                  <animate attributeName="opacity" values="0;1;1;0" keyTimes="0;.08;.92;1" dur="4.4s" begin="0.3s" repeatCount="indefinite" />
                </circle>
                <g className="nd">
                  <circle cx="122.3" cy="65.3" r="6" />
                  <text x="122.3" y="51.3">
                    WA
                  </text>
                </g>
                <g className="nd">
                  <circle cx="73.8" cy="297.7" r="6" />
                  <text x="73.8" y="283.7">
                    CA
                  </text>
                </g>
                <g className="nd">
                  <circle cx="204.9" cy="380.4" r="6" />
                  <text x="204.9" y="366.4">
                    AZ
                  </text>
                </g>
                <g className="nd">
                  <circle cx="327.5" cy="290.3" r="6" />
                  <text x="327.5" y="276.3">
                    CO
                  </text>
                </g>
                <g className="nd">
                  <circle cx="427.5" cy="470.1" r="6" />
                  <text x="427.5" y="456.1">
                    TX
                  </text>
                </g>
                <g className="nd">
                  <circle cx="516.3" cy="141.6" r="6" />
                  <text x="516.3" y="127.6">
                    MN
                  </text>
                </g>
                <g className="nd">
                  <circle cx="604.8" cy="271.9" r="6" />
                  <text x="604.8" y="257.9">
                    IL
                  </text>
                </g>
                <g className="nd hq">
                  <circle className="ring" cx="698.3" cy="214.0" r="9" />
                  <circle cx="698.3" cy="214.0" r="8" />
                  <text x="698.3" y="196.0" style={{fill:"#ffb020"}}>
                    Michigan HQ
                  </text>
                </g>
                <g className="nd">
                  <circle cx="818.1" cy="175.6" r="6" />
                  <text x="818.1" y="161.6">
                    NY
                  </text>
                </g>
                <g className="nd">
                  <circle cx="777.3" cy="350.4" r="6" />
                  <text x="777.3" y="336.4">
                    NC
                  </text>
                </g>
                <g className="nd">
                  <circle cx="723.9" cy="424.3" r="6" />
                  <text x="723.9" y="410.3">
                    GA
                  </text>
                </g>
                <g className="nd">
                  <circle cx="770.9" cy="523.5" r="6" />
                  <text x="770.9" y="509.5">
                    FL
                  </text>
                </g>
              </svg>
            </div>
          </div>
        </section>
        <section>
          <div className="wrap">
            <div className="head">
              <h2>
                Why agencies and networks work with us
              </h2>
            </div>
            <div className="nl">
              <div className="rv">
                <span>
                  01
                </span>
                <h3>
                  Insurance only
                </h3>
                <p>
                  We know an auto shopper from a Medicare shopper, and we treat them differently.
                </p>
              </div>
              <div className="rv">
                <span>
                  02
                </span>
                <h3>
                  Checked first
                </h3>
                <p>
                  Phone, email and consent are verified before the lead is sent to you.
                </p>
              </div>
              <div className="rv">
                <span>
                  03
                </span>
                <h3>
                  Flexible deals
                </h3>
                <p>
                  CPL, CPA or a hybrid. Pick what works for your books.
                </p>
              </div>
              <div className="rv">
                <span>
                  04
                </span>
                <h3>
                  Your states and lines
                </h3>
                <p>
                  Send us the states and coverage types you are licensed for.
                </p>
              </div>
              <div className="rv">
                <span>
                  05
                </span>
                <h3>
                  Straight answers
                </h3>
                <p>
                  Message the CEO directly on WhatsApp or Telegram.
                </p>
              </div>
              <div className="rv">
                <span>
                  06
                </span>
                <h3>
                  Compliance minded
                </h3>
                <p>
                  Clear disclosures and TCPA-aware consent on every form.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section className="alt">
          <div className="wrap">
            <div className="band">
              <div>
                <h2>
                  Ready to grow your pipeline?
                </h2>
                <p>
                  Tell us what you need and we will reply within 24 hours.
                </p>
              </div>
              <Link to="/partner.html" className="btn s">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-handshake" />
                </svg>
                {" Partner with us"}
              </Link>
            </div>
          </div>
        </section>
        <section id="quote" className="alt">
          <div className="wrap split">
            <div>
              <h2>
                Get a free quote
              </h2>
              <p className="lead">
                Choose any service from the full list and send your details. Your request goes straight to our team by email, and you can continue on WhatsApp.
              </p>
              <ul className="info" style={{marginTop:"26px"}}>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-envelope" />
                  </svg>
                  <div>
                    <b>
                      Email
                    </b>
                    <br />
                    <a href="mailto:Marketing@loadhubamerica.com">
                      Marketing@loadhubamerica.com
                    </a>
                  </div>
                </li>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#brands-whatsapp" />
                  </svg>
                  <div>
                    <b>
                      WhatsApp
                    </b>
                    <br />
                    <a href="https://wa.me/16468956658" target="_blank" rel="noopener">
                      +1 (646) 895-6658
                    </a>
                  </div>
                </li>
              </ul>
            </div>
            <div className="card">
              <form name="lead" method="POST" data-lead="">
                <input type="hidden" name="form-name" value="lead" />
                <p className="hp">
                  <label>
                    {"Leave empty "}
                    <input name="bot-field" />
                  </label>
                </p>
                <div className="row">
                  <div>
                    <label htmlFor="n-h">
                      Full name
                    </label>
                    <input id="n-h" name="name" required autoComplete="name" />
                  </div>
                  <div>
                    <label htmlFor="p-h">
                      Phone
                    </label>
                    <input id="p-h" name="phone" type="tel" required autoComplete="tel" />
                  </div>
                </div>
                <div className="row">
                  <div>
                    <label htmlFor="e-h">
                      Email
                    </label>
                    <input id="e-h" name="email" type="email" required autoComplete="email" />
                  </div>
                  <div>
                    <label htmlFor="s-h">
                      Service
                    </label>
                    <select id="s-h" name="service" required>
                      <option value="">
                        Select a service
                      </option>
                      <optgroup label="Personal">
                        <option value="Auto Insurance">
                          Auto Insurance
                        </option>
                        <option value="Home Insurance">
                          Home Insurance
                        </option>
                        <option value="Health Insurance">
                          Health Insurance
                        </option>
                        <option value="Life Insurance">
                          Life Insurance
                        </option>
                        <option value={"Dental & Vision"}>
                          Dental &amp; Vision
                        </option>
                        <option value="Travel Insurance">
                          Travel Insurance
                        </option>
                        <option value="Pet Insurance">
                          Pet Insurance
                        </option>
                        <option value="Umbrella Insurance">
                          Umbrella Insurance
                        </option>
                        <option value={"Flood & Earthquake Insurance"}>
                          Flood &amp; Earthquake Insurance
                        </option>
                      </optgroup>
                      <optgroup label="Business">
                        <option value="General Liability">
                          General Liability
                        </option>
                        <option value="Commercial Auto">
                          Commercial Auto
                        </option>
                        <option value="Workers’ Compensation">
                          Workers’ Compensation
                        </option>
                        <option value={"Professional Liability (E&O)"}>
                          Professional Liability (E&amp;O)
                        </option>
                        <option value="Business Owner’s Policy (BOP)">
                          Business Owner’s Policy (BOP)
                        </option>
                        <option value="Cyber Insurance">
                          Cyber Insurance
                        </option>
                        <option value="Commercial Property">
                          Commercial Property
                        </option>
                        <option value="Group Health">
                          Group Health
                        </option>
                      </optgroup>
                      <optgroup label="Special">
                        <option value="Disability Insurance">
                          Disability Insurance
                        </option>
                        <option value="Long-Term Care">
                          Long-Term Care
                        </option>
                        <option value="Annuities / Retirement">
                          Annuities / Retirement
                        </option>
                        <option value="Trucking Insurance">
                          Trucking Insurance
                        </option>
                      </optgroup>
                      <optgroup label="Finance">
                        <option value="Personal Loans">
                          Personal Loans
                        </option>
                        <option value="Debt Relief">
                          Debt Relief
                        </option>
                        <option value="Credit Repair">
                          Credit Repair
                        </option>
                        <option value="Mortgage">
                          Mortgage
                        </option>
                        <option value="Tax Help">
                          Tax Help
                        </option>
                      </optgroup>
                      <optgroup label="Other">
                        <option>
                          Partner with us
                        </option>
                        <option>
                          Other
                        </option>
                      </optgroup>
                    </select>
                  </div>
                </div>
                <div>
                  <label htmlFor="m-h">
                    How can we help?
                  </label>
                  <textarea id="m-h" name="message" rows="4" />
                </div>
                <label className="chk">
                  <input type="checkbox" name="consent" value="yes" required />
                  <span>
                    {"I agree to be contacted by Loadhub Marketing and its partners by phone, text or email and accept the "}
                    <Link to="/privacy.html" style={{textDecoration:"underline"}}>
                      Privacy Policy
                    </Link>
                    .
                  </span>
                </label>
                {" "}
                <button className="btn p" type="submit">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-paper-plane" />
                  </svg>
                  {" Get my free quote"}
                </button>
                <p className="rt">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-clock" />
                  </svg>
                  {" We reply within 24 hours"}
                </p>
              </form>
              <div className="ok">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-circle-check" />
                </svg>
                <h3>
                  Request received
                </h3>
                <p>
                  We will reply within 24 hours. For a faster answer, message us on WhatsApp.
                </p>
                <p className="err" style={{display:"none",color:"#d9480f"}}>
                  Automatic delivery is unavailable right now. Please use WhatsApp or email Marketing@loadhubamerica.com.
                </p>
                <br />
                <a className="btn s wal" target="_blank" rel="noopener" href="#">
                  <svg className="i" aria-hidden="true">
                    <use href="#brands-whatsapp" />
                  </svg>
                  {" Continue on WhatsApp"}
                </a>
              </div>
            </div>
          </div>
        </section>
              <script type="application/ld+json" dangerouslySetInnerHTML={{__html:"{\"@context\":\"https://schema.org\",\"@graph\":[{\"@type\":\"WebSite\",\"@id\":\"https://loadhubmarketing.com/#website\",\"url\":\"https://loadhubmarketing.com/\",\"name\":\"Loadhub Marketing\",\"alternateName\":[\"loadhubmarketing\",\"Loadhub\",\"Loadhub Marketing\"],\"inLanguage\":\"en-US\",\"publisher\":{\"@id\":\"https://loadhubmarketing.com/#organization\"}},{\"@type\":\"Organization\",\"@id\":\"https://loadhubmarketing.com/#organization\",\"name\":\"Loadhub Marketing\",\"alternateName\":\"loadhubmarketing\",\"url\":\"https://loadhubmarketing.com/\",\"logo\":{\"@type\":\"ImageObject\",\"url\":\"https://loadhubmarketing.com/logo-512.png\",\"width\":512,\"height\":512},\"image\":\"https://loadhubmarketing.com/og-image.png\",\"description\":\"Loadhub Marketing is a U.S. performance marketing and lead generation company for auto, health, finance and insurance brands.\",\"email\":\"Marketing@loadhubamerica.com\",\"telephone\":\"+1-646-895-6658\",\"founder\":{\"@type\":\"Person\",\"name\":\"M. Tayyab\",\"jobTitle\":\"CEO\"},\"address\":{\"@type\":\"PostalAddress\",\"streetAddress\":\"22518 Woodcreek Dr\",\"addressLocality\":\"Brownstown Twp\",\"addressRegion\":\"MI\",\"postalCode\":\"48134\",\"addressCountry\":\"US\"},\"contactPoint\":[{\"@type\":\"ContactPoint\",\"contactType\":\"sales\",\"email\":\"Marketing@loadhubamerica.com\",\"telephone\":\"+1-646-895-6658\",\"areaServed\":\"US\",\"availableLanguage\":\"English\"}],\"sameAs\":[\"https://t.me/Loadhub_america\"]}]}"}} />
      </main>
  )
}
