export const head = {
  "title": "Terms of Service | Loadhub Marketing",
  "tags": [
    {
      "name": "description",
      "content": "Terms of use for the Loadhub Marketing website and services."
    },
    {
      "name": "robots",
      "content": "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"
    },
    {
      "property": "og:type",
      "content": "website"
    },
    {
      "property": "og:title",
      "content": "Terms of Service | Loadhub Marketing"
    },
    {
      "property": "og:description",
      "content": "Terms of use for the Loadhub Marketing website and services."
    },
    {
      "property": "og:url",
      "content": "https://loadhubmarketing.com/terms.html"
    },
    {
      "property": "og:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    },
    {
      "property": "og:image:width",
      "content": "1200"
    },
    {
      "property": "og:image:height",
      "content": "630"
    },
    {
      "property": "og:image:alt",
      "content": "Loadhub Marketing, insurance lead generation"
    },
    {
      "property": "og:site_name",
      "content": "Loadhub Marketing"
    },
    {
      "property": "og:locale",
      "content": "en_US"
    },
    {
      "name": "twitter:card",
      "content": "summary_large_image"
    },
    {
      "name": "twitter:title",
      "content": "Terms of Service | Loadhub Marketing"
    },
    {
      "name": "twitter:description",
      "content": "Terms of use for the Loadhub Marketing website and services."
    },
    {
      "name": "twitter:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    }
  ],
  "canonical": "https://loadhubmarketing.com/terms.html"
}

export default function Terms() {
  return (
    <main>
        <section className="phead">
          <div className="wrap doc">
            <h1 style={{fontSize:"clamp(2rem,4.5vw,3rem)"}}>
              Terms of Service
            </h1>
            <p>
              Last updated: 2026
            </p>
            <h2>
              Acceptance
            </h2>
            <p>
              By using this website you agree to these terms. If you do not agree, please do not use the site.
            </p>
            <h2>
              Our services
            </h2>
            <p>
              Loadhub Marketing generates leads and connects consumers with advertisers. We do not sell insurance, make loans or give financial, legal or medical advice.
            </p>
            <h2>
              Your responsibilities
            </h2>
            <p>
              You agree to give accurate information and not to misuse the site, submit false requests or attempt to disrupt it.
            </p>
            <h2>
              Contact consent
            </h2>
            <p>
              When you submit a form you agree that we and our partners may contact you by phone, text or email about the service you chose. Message and data rates may apply. You can opt out at any time.
            </p>
            <h2>
              Intellectual property
            </h2>
            <p>
              All content, logos and design on this site belong to Loadhub Marketing and may not be copied without permission.
            </p>
            <h2>
              Limitation of liability
            </h2>
            <p>
              The site is provided “as is”. To the extent allowed by law, we are not liable for indirect or consequential damages from using the site or from offers made by third parties.
            </p>
            <h2>
              Contact
            </h2>
            <p>
              Questions about these terms: Marketing@loadhubamerica.com.
            </p>
          </div>
        </section>
      </main>
  )
}
