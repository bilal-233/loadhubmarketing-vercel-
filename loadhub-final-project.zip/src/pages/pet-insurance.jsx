import { Link } from 'react-router-dom'

export const head = {
  "title": "Pet Insurance Quotes | Loadhub Marketing",
  "tags": [
    {
      "name": "description",
      "content": "Help with vet bills for dogs and cats. Request a free Pet Insurance quote through Loadhub Marketing."
    },
    {
      "name": "robots",
      "content": "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"
    },
    {
      "property": "og:type",
      "content": "website"
    },
    {
      "property": "og:title",
      "content": "Pet Insurance Quotes | Loadhub Marketing"
    },
    {
      "property": "og:description",
      "content": "Help with vet bills for dogs and cats. Request a free Pet Insurance quote through Loadhub Marketing."
    },
    {
      "property": "og:url",
      "content": "https://loadhubmarketing.com/pet-insurance.html"
    },
    {
      "property": "og:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    },
    {
      "property": "og:image:width",
      "content": "1200"
    },
    {
      "property": "og:image:height",
      "content": "630"
    },
    {
      "property": "og:image:alt",
      "content": "Loadhub Marketing, insurance lead generation"
    },
    {
      "property": "og:site_name",
      "content": "Loadhub Marketing"
    },
    {
      "property": "og:locale",
      "content": "en_US"
    },
    {
      "name": "twitter:card",
      "content": "summary_large_image"
    },
    {
      "name": "twitter:title",
      "content": "Pet Insurance Quotes | Loadhub Marketing"
    },
    {
      "name": "twitter:description",
      "content": "Help with vet bills for dogs and cats. Request a free Pet Insurance quote through Loadhub Marketing."
    },
    {
      "name": "twitter:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    }
  ],
  "canonical": "https://loadhubmarketing.com/pet-insurance.html"
}

export default function PetInsurance() {
  return (
    <main>
        <section className="phead">
          <div className="wrap">
            <p className="bc">
              <Link to="/">
                Home
              </Link>
              {" / "}
              <Link to="/services.html#personal">
                Personal
              </Link>
              {" / Pet Insurance"}
            </p>
            <div className="dh">
              <div className="ico big">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-paw" />
                </svg>
              </div>
              <div>
                <h1 style={{fontSize:"clamp(2rem,4.5vw,3.2rem)"}}>
                  Pet Insurance
                </h1>
                <p className="lead">
                  Help with vet bills for dogs and cats.
                </p>
              </div>
            </div>
            <div style={{display:"flex",gap:".8rem",flexWrap:"wrap",marginTop:"22px"}}>
              <Link to="/contact.html?service=Pet%20Insurance#quote" className="btn p">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-paper-plane" />
                </svg>
                {" Get a quote"}
              </Link>
              <a className="btn o" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Pet%20Insurance" target="_blank" rel="noopener">
                <svg className="i" aria-hidden="true">
                  <use href="#brands-whatsapp" />
                </svg>
                {" WhatsApp us"}
              </a>
            </div>
          </div>
        </section>
        <section style={{paddingTop:"20px"}}>
          <div className="wrap split">
            <div>
              <h2>
                What it covers
              </h2>
              <ul className="cv">
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Accidents and illness
                  </span>
                </li>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Surgery and hospital stays
                  </span>
                </li>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Prescription medication
                  </span>
                </li>
                <li>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-check" />
                  </svg>
                  <span>
                    Optional wellness add-ons
                  </span>
                </li>
              </ul>
              <h2 style={{marginTop:"30px"}}>
                Who it is for
              </h2>
              <p className="lead">
                Dog and cat owners who want help with unexpected vet bills.
              </p>
            </div>
            <div className="card">
              <h3>
                Get a free quote
              </h3>
              <p>
                Choose Pet Insurance on our form and a partner will get back to you. It takes about a minute.
              </p>
              <br />
              <Link to="/contact.html?service=Pet%20Insurance#quote" className="btn s">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-paper-plane" />
                </svg>
                {" Get a quote"}
              </Link>
            </div>
          </div>
        </section>
        <section className="alt">
          <div className="wrap doc">
            <h2>
              Frequently asked questions
            </h2>
            <br />
            <details>
              <summary>
                What does Pet Insurance cover?
              </summary>
              <p>
                Typical coverage includes: accidents and illness; surgery and hospital stays; prescription medication; optional wellness add-ons. Exact terms depend on the provider and the plan you choose.
              </p>
            </details>
            <details>
              <summary>
                Who needs Pet Insurance?
              </summary>
              <p>
                Dog and cat owners who want help with unexpected vet bills.
              </p>
            </details>
            <details>
              <summary>
                How do I get a quote?
              </summary>
              <p>
                Select Get a quote, choose Pet Insurance and send your details. One of our partners will contact you with options.
              </p>
            </details>
            <details>
              <summary>
                Does it cost anything to request a quote?
              </summary>
              <p>
                No. Requesting a quote through Loadhub Marketing is free and does not oblige you to buy.
              </p>
            </details>
            <details>
              <summary>
                Is Loadhub Marketing the provider?
              </summary>
              <p>
                No. We are a lead generation company. Independent partners make the offers and provide the service.
              </p>
            </details>
          </div>
        </section>
        <section>
          <div className="wrap">
            <div className="head">
              <h2>
                More in Personal
              </h2>
            </div>
            <div className="grid g3">
              <article className="card sc rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-car-side" />
                  </svg>
                </div>
                <h3>
                  <Link to="/auto-insurance.html">
                    Auto Insurance
                  </Link>
                </h3>
                <p>
                  Car, motorcycle, RV and boat coverage.
                </p>
                <div className="act">
                  <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Auto%20Insurance" target="_blank" rel="noopener">
                    <svg className="i" aria-hidden="true">
                      <use href="#brands-whatsapp" />
                    </svg>
                    {" WhatsApp"}
                  </a>
                  <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Auto%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Auto%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-envelope" />
                    </svg>
                    {" Email"}
                  </a>
                </div>
              </article>
              <article className="card sc rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-house" />
                  </svg>
                </div>
                <h3>
                  <Link to="/home-insurance.html">
                    Home Insurance
                  </Link>
                </h3>
                <p>
                  Homeowners, renters and condo coverage.
                </p>
                <div className="act">
                  <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Home%20Insurance" target="_blank" rel="noopener">
                    <svg className="i" aria-hidden="true">
                      <use href="#brands-whatsapp" />
                    </svg>
                    {" WhatsApp"}
                  </a>
                  <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Home%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Home%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-envelope" />
                    </svg>
                    {" Email"}
                  </a>
                </div>
              </article>
              <article className="card sc rv">
                <div className="ico">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-heart-pulse" />
                  </svg>
                </div>
                <h3>
                  <Link to="/health-insurance.html">
                    Health Insurance
                  </Link>
                </h3>
                <p>
                  Individual, family, Medicare and Medicaid options.
                </p>
                <div className="act">
                  <a className="pill w" href="https://wa.me/16468956658?text=Hello%20Loadhub%20Marketing%2C%20I%20would%20like%20a%20quote%20for%20Health%20Insurance" target="_blank" rel="noopener">
                    <svg className="i" aria-hidden="true">
                      <use href="#brands-whatsapp" />
                    </svg>
                    {" WhatsApp"}
                  </a>
                  <a className="pill" href={"mailto:Marketing@loadhubamerica.com?subject=Quote%20request%3A%20Health%20Insurance&body=Hello%20Loadhub%20Marketing%2C%0A%0AI%20would%20like%20a%20quote%20for%20Health%20Insurance.%0A%0AName%3A%0APhone%3A%0A"}>
                    <svg className="i" aria-hidden="true">
                      <use href="#solid-envelope" />
                    </svg>
                    {" Email"}
                  </a>
                </div>
              </article>
            </div>
          </div>
        </section>
        <script type="application/ld+json" dangerouslySetInnerHTML={{__html:"{\"@context\":\"https://schema.org\",\"@type\":\"FAQPage\",\"mainEntity\":[{\"@type\":\"Question\",\"name\":\"What does Pet Insurance cover?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"Typical coverage includes: accidents and illness; surgery and hospital stays; prescription medication; optional wellness add-ons. Exact terms depend on the provider and the plan you choose.\"}},{\"@type\":\"Question\",\"name\":\"Who needs Pet Insurance?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"Dog and cat owners who want help with unexpected vet bills.\"}},{\"@type\":\"Question\",\"name\":\"How do I get a quote?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"Select Get a quote, choose Pet Insurance and send your details. One of our partners will contact you with options.\"}},{\"@type\":\"Question\",\"name\":\"Does it cost anything to request a quote?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"No. Requesting a quote through Loadhub Marketing is free and does not oblige you to buy.\"}},{\"@type\":\"Question\",\"name\":\"Is Loadhub Marketing the provider?\",\"acceptedAnswer\":{\"@type\":\"Answer\",\"text\":\"No. We are a lead generation company. Independent partners make the offers and provide the service.\"}}]}"}} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{__html:"{\"@context\":\"https://schema.org\",\"@type\":\"BreadcrumbList\",\"itemListElement\":[{\"@type\":\"ListItem\",\"position\":1,\"name\":\"Home\",\"item\":\"https://loadhubmarketing.com/\"},{\"@type\":\"ListItem\",\"position\":2,\"name\":\"Personal\",\"item\":\"https://loadhubmarketing.com/services.html#personal\"},{\"@type\":\"ListItem\",\"position\":3,\"name\":\"Pet Insurance\",\"item\":\"https://loadhubmarketing.com/pet-insurance.html\"}]}"}} />
      </main>
  )
}
