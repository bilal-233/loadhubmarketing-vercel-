import { Link } from 'react-router-dom'

export const head = {
  "title": "Get a Free Quote | Contact Loadhub Marketing",
  "tags": [
    {
      "name": "description",
      "content": "Request a free quote for any insurance or finance service, or contact Loadhub Marketing by email or WhatsApp."
    },
    {
      "name": "robots",
      "content": "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"
    },
    {
      "property": "og:type",
      "content": "website"
    },
    {
      "property": "og:title",
      "content": "Get a Free Quote | Contact Loadhub Marketing"
    },
    {
      "property": "og:description",
      "content": "Request a free quote for any insurance or finance service, or contact Loadhub Marketing by email or WhatsApp."
    },
    {
      "property": "og:url",
      "content": "https://loadhubmarketing.com/contact.html"
    },
    {
      "property": "og:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    },
    {
      "property": "og:image:width",
      "content": "1200"
    },
    {
      "property": "og:image:height",
      "content": "630"
    },
    {
      "property": "og:image:alt",
      "content": "Loadhub Marketing, insurance lead generation"
    },
    {
      "property": "og:site_name",
      "content": "Loadhub Marketing"
    },
    {
      "property": "og:locale",
      "content": "en_US"
    },
    {
      "name": "twitter:card",
      "content": "summary_large_image"
    },
    {
      "name": "twitter:title",
      "content": "Get a Free Quote | Contact Loadhub Marketing"
    },
    {
      "name": "twitter:description",
      "content": "Request a free quote for any insurance or finance service, or contact Loadhub Marketing by email or WhatsApp."
    },
    {
      "name": "twitter:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    }
  ],
  "canonical": "https://loadhubmarketing.com/contact.html"
}

export default function Contact() {
  return (
    <main>
        <section className="phead">
          <div className="wrap" style={{textAlign:"center"}}>
            <h1 className="nm" style={{fontSize:"clamp(2rem,4.5vw,3.2rem)"}}>
              {"Let’s "}
              <span>
                work together
              </span>
            </h1>
            <p className="lead" style={{margin:"14px auto 0"}}>
              Reach out and we will respond within 24 hours.
            </p>
          </div>
        </section>
        <section id="quote" style={{paddingTop:"20px"}}>
          <div className="wrap split">
            <div>
              <div className="card pc">
                <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCADwAPADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD5C52460uOMDOPelU4J4zilyOuetScw1uMe9GOhpw57EgUvUYOAAKAGhcMO/alAPIyR6YoJOQcdOlOJOzKn5sdqARHk4xkD60eh44pw2HGM5PTPNIQAcZGKBgeARn8KMc/hSqAMGlHGDjPrQAhBOOmO+KVMEcYzRgAcZBz+FBA54waCRT06ig47rwKcMD1/Km8Acg0wDg54IHrRggEdcU4g46delGRnk4zwaYCEZ4H4UvGAuBz1xSq3Y884FIFw3Izn36UAHJbGTk9BRw3AGCKcuS/HyjpgUHGTgdOtAAvyt8x4p+QTyDxTU6gHGDyPanhWOc9M8UAxrECTP6U7GflPWhlGS2BxxTgMbcjPGCO9AhuAerY7YFOOMFTzgdRQAOONpyc/SnLnoRj/CmNDBweVxn0Pal7jBJOO1LgKcKKVAewwcdKYMQDja6hRnr3oJDADd15wKeynHyr6Hk005PDMDzigRR+XB75FBHIBUfnTiOcbRikGNxI+lZjEAwTg8fSgZ6j155p2Rjjnigr8o6DPvQMTKklQSM80AZUNj8qXPOCM/TihdvIB7UwuIAFBwPofSl29GI696VQSMcClHTbgY6g0guNwT3AFBzjaBkn0p8UUk8iwxoXdjgIBk1pKNIsrASSStc3xcERKP3QXPIY9elK5UYtmUQWwoUkk1K0EyOd0TrgZO4YqVL25uLpY7VUgxJujVeAp+po12G/trzZfzGWQqGDb92QaL3K5bENvBc3EgjggllcqXwqknA7/SmELydx6dDVnRNb1PRdTi1DTbySC4jHDDnI7g54I9q0v+EmlaPUhLpOkvJqBYyTNbDdHnn5P7tHMKyZiYwc56cGjB4HHXNIJG8sptH49c0iseaakQSE5YEDHtQCeTg56VYsrUXUEzC6gieJC4SQ4L84wp7moChVihUhieAetUIBkkAgA05iVJJwQeg+tDqyFgww3Tn9aE57AjGKBXFACNjaMdAe1OVTznOB+tAPOByfTHWnJwW3Hn2PSmgFwoBIPfuKXG4Hg5Jx0pcbgFBBwKdsZe3OOaYDV6Y+7j8aNvyHGSx56dKfsOM5xlaF7dMetADMDqT/APXNLhuo4GcGnSbQhwBQgXngnHOKLAN28FiTn1z1poUHfgfKRxn1p4U78LjGOM0pzsCsPm3c+1FgM/jbk0gGCCKUqOg6UpA5xg81mMQDGSKQ8jBBNO6EjmgDPQdKYDQQCPlA9+9LjJyFP50q9CNufelUbh0yaAEII7daU4LY5545HFLjnkYrtPg54ctfEXje3t9Rs57rTLdGuL1Y3CbY1HUsegzUSdkXCPM7GV9nufDVlp2sw3dpJc38MjRKrZktxnGWHY+lcyFy5LE88k1t+OryHUPGGozWqqlu1wyQIvRUBwo/+vWZcW8tsEMmPm9O1KOquaVfd0ElhWNUVSGLAEHuM9qbKrGbZPuBTAGecVPOQ0ETKpLAc+2DVQs8r7iSSeuaozQSjLYHSmhDnr9Kv2di9wVKHdnr7Vbn0aS0vYYrnGyUg/Ic4B/rRYluxjBCT83WrK2cwiEwjLIe4FdPP4cFvfrZ3DJvkUSwyZ+V0749+1auobdCWGKF4pChDj5c/NjlD9QcVShdE3OJu9OeKNJIjuRhkEdR9a2vCOtXekpJex6ZY6gIQFX7XHvMJzkMvofzrfnis7nRRr1iY49oBvID0BzjgfrS6Fp1jc7pIfk+0Bj0+UY459jmqUBqTRzesHw/d2yXGnzail/KwedblFEeTksQwPrjjHerFz4I8RW/hpfEf2OObTSoLzQTLJ5QJwN4Byv4ip4NElt9ZvNLljGCpYRk5PB7H3FVWi1LQdRWS2aRFch9hGUkAOQGX+L8amzRSakzEUNkd8dDTkUqo7AHJ969F1XT9N8aeHJ9X0LS7fTdX0mFPt2nWyHFwmTunT3BPIHpXAKmQyk5I4NUncUo8oxVwxJ+hxSgA52nGBwDzmpERt21SeRk+lLt2grx7nvTJGbTtx936UYGVA+nSnIoVRkkkg0uM7T0IOOBTAYVXcVKDA5H1pCMqTk8ehqZwWUkP2wfrTI13AMeecGgBpAyfnZSBwKFwAMqM45OaeqghRuLE56dqawByyjnPNAGYMkYHDUuCAuR9aXgg54z3o6qMZPtWaGNJxk9cnFA4P8ASnDBbIXPalbIbnGelMBMfP0GOtHIz83Hb3p+BgjvmmnOB7D0pAInDBQOT29697t007wr8ALK7sdOuLa+1uXytQu3YZlhHO0f3Uzj615H4CtBeeLtLhk006oktzGrWgfYZwT93PavqX4/WlrrtheeGbSS30uTTbJXis2dFiiQDJGfXtXPWdmkduFgrNs+OZCI7p9p6Mcc578VftonvrZ1xl/vZJ5JqfQtNhvJ5EmkVAmcE9D2q8I7axV4EuI7g5+TylO8H61uo6HJN3ZR0iW2t/Ng1O2fY4wGXsahKW1tfCS1ImizkBuD9K6PTPCGr6rgyyPBEcEhuSRXqPgn4aaNBKrXFs13IDndJ0H4Vx1cXCmdtDL6tZ6HkcH2y6v4n0fTZ1OAGQJvDEdeKtX/AIV8WM32v+ybwI7Zz5RGG/pX1jomh2dmiLDZQRgdNiAYro4rZTHxGGHcEcVwvNtdEetHIdPeZ8Q6gNeEcMN7bzB7c4RmQ5HtUceja5qjySxW80rAbm4PAPGa+27/AMNaTqce2906CQnoQuCKi0jwlpOlhvs9qrZz99QcA9vpVf2o+qJ/sJ30Z8QvaavYrPbNFOgc4dCvGR2q3pevzaZpz2kaZkkJGSM4TOSP5V9o3nhbRLmR3l02BnLBidg5OOtcD4v+DvhzVJZZ4YntJSuF8rpnHpWlPMot+8Y1sknFXTPmldXlm1u2vpZGVg4YkHoAAMflXYxX9lr2sCE7FZ/uMF4J27cf1pni34Ua7pLSSWh+3QrxlRhvyritPmu9N1SOdkkWSBuVIIwRXowrRnseTUw06WkkdppVtq/g/X4tW09zBPbSZyeki9xjuD0rovi/8ObS08N6d498NNJPo2qZNwrdbecnJX/drY8MxQ+MrSIMVF8sPzliBlWJxj3r2T4U+EH1D4f+IfAOrqTE4MkBdflQkcEfQ4pSlyyNoUuaB8UhSMAjFLtDEsO3Q16f8YfDNl4NtLXw9bxefdLM5urxlAMrADKqOyDPfqa4TU9D1TSbGyu7+zkt4r1GeAyjBdQeuOuK3jJM5JQaZlnOOoK+mKTbiLIbBPpUuMgntjn0pjICdoPI5qiBrJhFYDJHzZNN+RsBTgZyTT0ZsDgEE9zQU+bO0AFqAEyQdx/AdKaFYMduMVIcpuHXB9KQjLcA5xnPtQBkZ5+UZyODS8k5GfqKRVHXIwKec8Jnp6d6gY1h0AGAB60pyR83Qc0pUY+YYPvSqGMY6YFAAxG4YzyP1oB5X5u9KRkHGCT29KFJKqc5x1FAHuH7PXjHwzZ+I9C0Rvh9YXupNcoDqMkzb05+/joMdah/aq8Vab4l+Js+l6JLB9mtnKT3SYxI/fkdQK4v4ceLv+ETstZuItHtLq5nsXghuHOHgLcblri7ANcXkYZgXZxkt39TWfLzS1Onn5YaG7NFFaW7La4ERH7yaQct/uj0rQ8C6X9ouPtckZIJxGp6fWnaxHBd3VraLl0YBXYLx+FeleGtIjihtjHGoUAZI9BXNjKzgrI3y/DOtK7Ol8M6L+6BKkkr83tXoXh3ShEgBXn1NU/D9shRXUAJxXV2gwwxj8BXzdSTk9Wfa0qUYRVkWrKzQLtIPNX4rUIvC020VQM8mtGFlK8CrhBGc5yTKwtxjdtPFBtsMBtPNaCbcfeFPKDAPUmtvZJnP7aSZlSWoGcryaryWZbIC5GK3DCpHao2hAzxk1EqPYqNfucLrejByXVOe+K8j+Ivga01BHcQCK4AO2VF/nX0Xd2oK8gc9K5jVtOimEkXlg5HU0qdWVGW46tGniI6rU+UfCNzfeF/GNkLhWDwyLgHhSM8Gv0A8FR295plvqsIU/aIFO4DrXyj8Q/CCXNu7RIEuIRvjPr7V7J+zf8AEbTNT8OW/h2/dLS8tQIkV25kr3KFZVtWfOV8PKheJwv7QHhzw94O1a98X6raRXNzLcMdIsWk3LLIQC0kg/uKecd6+afFmvar4k1R9S1a7a4nPAJGFRewUdAK+zv2mtC8AXEEGs+Mb7UrZvKaGA26lk3dsjtXxRqcMMVzMlvN51uGPlPtxuXPBxXbSsedWb3M8rnac5A6+9MkX0XBPpUxUn7pBy2KYwLHJOCO45zWxzEUgJYZBwOAAOKUocBuOegzUmxsc5AyePWkBbkbFB6AGgCHBztO4gd/WlUDgh+2M9KkYbBk4wMjOaR48YKtu9QKAMRVGFKgcUu1QnzE/hSohzgEeppQcAgjNQMRQQDkg84pxwOp47Cl24IAGAeTTiCGyDjvTENCgk424pcZP1HankZwc8Uix4UZ5pALMjLbNKVJQts34OAeuAelQWsvlXAl25wflBrpYLjf4A1WwmkTbHcwzwKTg7+QcfhXLqAvIYk5pbFtaHoWnXdnLcWQG0+XGq8dATya9h8O2qGzjcYXdjAPpXjHwo0uW91H7Q6boIDznpntXuFncxW0Y3kApgkZwK8THz5p2R9LlFLkhzs7mweOKBEX0H0rdsLhcBQVLe1eH+IPiGY7n7Dpa+dNnaWX7q1q+FfGeH/0/UY1IJ3c1xrBVGuax6bzCjzctz2q2ad5TuChf4cd60IzKq1y/hXxRpOpALHfQ57fN1ru7e1EkSsvOfShYaY54unbQpxTspA6mryS5XJFJLYkDAXBpyWr7AADnvVKnOOhlOpTkrkYnO4g9jTjJuORTjandyKikULnNJqaeok4SWgydiVHQ1RmiU5JAzVlpVORuqP19DWMtTpp+6cZ4ksRLIMKDx+VeBeIjceGfGczWhMSlhJGV4IJ9K+m9Tt/MIIGeK8C+OentDrME+1hkbdy/wAq6cDN8/KcmaU+aiprdHrfhm8s/jJ8L59G1K8aLVtPQnI53jGFLA9q+U/GXhnVPDGsS6Tqts9vNHyoboy54YHuK9I+A/iibw78QLCaTH2e5b7POvZkY45ro/2uLWaK5gEvhdbSBZyLTUUut/mIRkrt/hHtXuUXaVj5mvHmjzHzqyYy4+914FIFAByOOMDuTU7Idu0A7jwBntTHGMMDnAwK6zhI3DZUHIXp0psyAoWUAE9fWpfuKRkjsTTAM56HPvQAwADaSMHGeaRANzsCSPQdRUp2s4G7j3pDwx2jqMDFAGAcZ4FKhOCThRnr3pxy3H8RUUrHHTjpx2NQAh5OTzzwaeBsHPAoIJLMoHTGKe3JxjoaoY0hQBwT7DrTxuC9elOAVcg56dRShTjDAdO1JgPSES2V2TKAUjDhTyTzzWWpzkAEknNbMLyxxTxwkASwlG9x1rMs0Mk8cb45cLx71nMtK9j3D4c2Saf4bs0VQHdRI57kmsLx9rl/NqT6TpZfC4VynUn+7XZaJA/9lqsQJeOEBAB7V13w68E2tpELq8tke4c+YWYZOc5rw/aRVRykfVexnOnGENjzHwr8O/F2o6arw6XJAjnli+1yO/Wultvhb40somB0SG5j7R+d94Hv9a9luPEdnpshgjkj3BtpPbPpjvWdB8TbBp7iL7Yx8nmQiAkIOnPpzXRDGztojnlllOL1nqeLy6R408OXqNdaPcx26EHzVTcQvcV7H8LfHFxdT2trNJIg2ENE5OVP412Gl61bapaRyJ5N1BJ0Kdfrg1X1Pw/pbTRXsMEcTgnDxjafxpSxTau0aU8ByvR3PRtPuIryAOVwc4xU8nkQKcqKwfDkqpAily2B1NWtVuFZG+bAA65qvrEfZ8xm8PP2nKZXjPxPa6NahlBeVhuCjqcdq861H4r2kUTyXWlXSKiKznA4z2+tbfiXQtT8RXsDwTxQwRDGTyW/+tWZbfB/z8teayWBkMm3y8jOMD8qdOVOpuKp7Wl8JQj8d6ZfKslvNcRyuu5VMZGPSrXh/wAbw3V6NPuvkk/gOeGpbn4QXtvHMunarC8bnjcpBA7iuD8ReCdd0EjzYJJIwcx3CnJQ+59KmrhaTXuhSxlaL949uG2VMqcivH/jha7ruCN1Xaw3DPT6113ws1+41G1k0+9P+m2vyuT/ABr60z4waUt3pltdL96KTDfQiuShF06iPSxMva4d2PFfCWk7fENudxmMbh8DocEZrf8A2ttOm0/xxY3f2qZ4dRskmWN2OI2HBArOt7p7a5iS1/dvEpBLDncD1HtXQftUznUdO8FanMhE02nsGO8diO3avch8dz5ippTseBuNxBx+NRhCpUtlsdRjtVlip44Az0xUTLtdicqu7GK6TzyHIClFAySQc85pREoRmJJwOPY+lPkGEOBgnqM0AqCyKMA9CT396YFb7qZIAz0B7U/ADlVXAABqWRR9wkmmDJkwGI+X+KkSc6o5POcHg+1OA5+UfWgKOg6jv609cv0PPA6dKlFC7WJXAx9acvJAIB7EnigrgbickZp8ag/KC3DA5x+lMLgoy+ORgYFTJEGUEA/59aREw3zAnI6+lXLSJWkQYPXr61LdjSMbs6n4d/D7V/GEl1JZqiW1rHmWSTpuPAUe5Ncy/h/UdG8WR6VqNsYZ45wGDDqM9a+x/wBlnQbaL4V+e6/Pe3buxx/dGBXE/tL+GIYNY0LW4o1WRp/JkYD74xkE15tXFSVS1tGe1SwcJ07rdFb4eWpeSDI3f3jXrJspjaDyCqcEA46V5p4CkMYiXCg4zmvUrScsqKQWPoK8epdzZ9DRVoKxx/hvwlJY+I11ia4e4uEclRKoKj2xUt38NTf6tql7Ddm1W/4nRB8rDOcY+td5GrkhjEBV6F1A5BX6VtSm1uzKpGPSJQt9FhtPD9lplvZxxm1QKk4bDf8A16z/ABDdNb6cIJFUT9tp6+9bl1MAp2k5PfNctqaefKZGzgHqT96pr1U9EXh6TWrNnw7PKLNC7cgd6j1y+dnigDgeZIAT6CrelwotnHhcHb3rG16ItqUIBxluK53dJI6Eoud7HQX9ylnbRWtuf3rLhQoyxNc34k8R32g3NlbT2Nw8l0QEy4UDJx+FdLZrBdIhnhHnoB844P4VFr3h6w1uOMXryO0JIj3HJAruik43Rwzk07GJofji2vbm4tlle3ntpCkqSjK5+vTrXSRXMOoRPDPGCSMMh5BHtWBougW+gWV5Zw6fFdpck7ml6nFVvDKahZXT2t9E3lKSYJCckL/dP0pSnZXTHGlz3TRWTwyNK8YpqFohW3kBD+gHpVrx8pPhG9KRszRqGAHXg11LyI8OGCn3rnfHoJ8HalsYoTF95eopwlzSTIlHlptM+fMXF/4ltreI7HLCOMAYBYnHPrW1+1TJFHr2h6IqwebpmmLFKyMDhjzgjtWx8IbO3XxFqHiO+iimtNItmuGV/uOw+6M+ua8p+IetXHifxTfa7dxBZLp2bHXavYfgK9ukru58xWfu2OUaM4JVVOKhYZbhs87h/WrjqFG4Mc+4qB0AbBUj3rpOJkPlYJBJAzyCKbtVtzlQBjv3qwwxhcglutRMnJ5I5GKCSJEGFPXAyTQcFtqqOeetTBS+4Ac7eM96YYivQc7c8+lIRzCqS2Pvcn8KfHncM5wOpFNHPGTjt9alClW2qc9M8dqRQioQWYjIP6VIoZ8kce1NUHbtbnByM09F2kDJPUkZoGPTOTgn8e1aOnht6tgAA9c4qoqgv82eeq/QdatW7EEKeflzyaUloaRep9rfs83Kv8ItMigYb/OljYA9yRWb+1BEI9A0bKE/6avI7fLVL9ky5V/h/PGzhmg1I8emUqx+03qCT+HNNUbty34Ax/umvGrRUZs+jwycopo4v4dxyXt2ET7qjHXrXtmjacFhUkDOBzXmXwRhRrQylVyW5r2iyAAUAYrhUeeZ6Tm4UxYrFWGNuTUqadnOVwAatpKkMZc4zimrOZTkHC967OSnHQ4HVqMwPETQ6fBgKZJnHyovWuVsbO8v70yXKhY1PyoK6/W4S16l2ieYu3YcdRUdg0QvjAYzHIRnaR1+lccoXmejRqctO73CK3kjTAHyjisLxAksV5byn7hba3tXfvDbmz3fxVg6nax3GEZM855rStQ5URQxXPIZZwsYVePkY6irW9guGG40uhEQzzW7KSgUMB6ZrUktIpVJj79qdOk7XRjVrJTakYrshPRs+lQvGrLgLWs1ptJBHSq1xbmP5gMionTkndlwqxexmsn8INYXjvzG8I3safedAgxxnJroZRxuAwaiFlHqElrbzDdEZ1Zh7DmqoqzuViJXgcPq3hG50j4A6iLaHbdTSLPe+ZxujB6CvmzUrYjIKnGeMnpX3F8QJ0j+HmvSSR7oxbFFj7DPSvi/WlBfGWxnkgdK9rDyuj5ivE5yVRu2nJJ+6R0qs8ROCgzt5zWhPG3ZssF4IHaoJVwF3Lnj6V2I89oqkE8n72M4I6e1RPlnztyDxx2qxIdseU4IPIx+tI4jOfvEgcDoKYiExsG3nOR0AFQlVDlM8Y475q02BtKvxyfQ4qEIccLnLde+KQjlQBjcPlwcHnkVJgqwYc46571HkE5G0L1PqDUo4BAUk5qSkPYAHLZAIFPX5AeCTxjPY0ijcFY5/wB1qlBRkAZjnI4xyaYXEBbPJBwP1qxAAMAkhuvNRjJUDGepx0qZBj5hyemT3oBM+lf2Q7iSTRfEtp8yxo8EoZRwDyCK6T9o9oD4e0dV/wCgioPHX5TXm/7KfinTNG8R3uj6tdLbW+qRKqSyfdEqn5c+gr1L9pvTprXwppV85QxLqcW0hshsg15WLpydW/Q+hwGIgqXK3qQfCaERWaJuxu5HGK9WtFYKD1GK8s8BTKY49uEKYGOteq6Y4khK+2K82CfOz1KsrwRx/j/xza+H5RAyh5iufnPyqPU1zMfxNOoSJBYAvhC7yn5UGO1c1428OXmtfES6tLzzBawguwHPmdxxXReG/C0cMJtrfSp3E0Xl7nGAR3xW0uVb7mdJVJ62sjNufiXcTaskURl8mLlztP7w98ewrqfD/j7TtW8uK4V4pgN0b7fu/jT7HwPbx3ovP7Ncs0ZiUE5AFWrL4faR9oWSeG5CK7MyZwCTjj6cChQu9C5cy3aZu3fiEQWSvM8SqU3eYXGCB3rIj8U6Aiy3El0bgoMu5YgD6DtWn4p8MaVrOmpaqr24jjMSeUMAA1xF18MVt7i4kttRZo3hVPJccMR1JqpQfVkRfZHe+FvEGl3hZ7eaNi2Ccc4Hp+tdJHLtkDq3yn9K+a5PD3ifwwkHlTN+8cggNlR1249q6n4d/Ee6Op2um6xGYmmPlShz9xtvy/macXKOxjWs3roe8MVkVScZxzVO6QbDj0osLjzUIYYZODS3LfKauUlKJjBSjOxhXSkAjHerOiwA3YYk5jByPrStEGDHBxg5qv4fmnuTNPDjy2l2An0UYrnXunZUfMrFP4w3v2P4Z6kgYBp5FiHvk18nawhLEtgDPFfSX7RV6kXhjTtPBbzZpjK2OmAMV84altHQ7sAE5Gea9jDRsj5/EtXMKZc5HJJPQcYFVJky5zjjscmtC7G4hQMZ7Hiq/ll88AgcEj1rsZ57KMqhVDgkAccD3onilBV2h2hgSpboR7VPtC4XK7xk5qOTzWCglmX+Et0UUEkBUZDYUEAjI/lUYD/KNjNuHX0qw0aGPKgsSdxI6A+lN2SCUp5gUg4GRxn0pEnFRso25HI4GfSpUQgYzjA4xTURWOOd3b6VIqgsVJ4K9c0IoXGBtOCAQfepyCCSM7j/ABZqJSpOSpPYDFTKpHCjsRkUASRgk5IGPftT1HLfPuGeBTFDEDL5xwasJz8wHfg+lAD4WIGVfDD+92r1LS9V1nUfgfrUd1M91bWGpWjK81wzuoJPAU8Ae9eXLuAHOeeeOteueCFe6/Z78dWdvc2btE0Fw8AGJlCt94n+76VnUV0bUpNM6L4Z+ID5AR3AZ+VLHqfWvdvC90PLUtIGAQM2TXxn8NtYEeox/aWLRxngMeFUc5r3vQvGaQaTfXIk85pDsijTrtA4rx6tFxndH0OHxKnTtI72ytl1Hxte6zD/AKhYhGrD+M9DWlFfz6Pe+S0fnW+7cmf4T6CvO/ht4qsItRlN9qS/aLl8CBMlY/avVTFBfQ7XAK9m/rWTUoy0OynOMl72xe0rXbSZ0hZGjYDLEjgGt+ExOrY2kGuIfTGi6jzFHRlPIra07zUhBS7YA9m5rso1W/dZyYrCQtzU5G1Hb2m1sonU1Tn06wmj8raoZjnrz+FVrt7iBRi4jbPqK57WZbuZceYR/dKcEVVSrFaWIw+EqTeky3r/AIftZoXMNwql2CoGwQPf9K8l8T+FLyTxTa38WyVJ7hUabGNpVgRtH4V6Po2jzO4a6kkWEfwluTWpqUVq1xZou0eRMrKvauVyTWh11YuPuylzGlptuUzIejKB+VLOpY4UHrUzXEaQqAcDFVt+SzbjtptKKsc8W5SuyMAM0g4+4cA+tPtbOW00+KF9vmR8ttHyknmotLAudYjt1G5cgv8ASpPEHjTwrpZmSa5aa4iJBiRCSSKuNF1I6GVav7OVjxz9o2R28QWKM33LNeB2ya8YvcDdvwfT0rv/AIqeIW8Sa8+oFQmQERQeijpmuHnjW4V1DRRsoz8/fHpXq04cqPHqz5jFmTCHYeByD6VXZSp3gKM8YHFXZdrZj+ZuQM9qhZQu7MZ46YrY5WUHjyxOfQDI4qMoSoPVjwRnp6VcdFCYyS3Hy1Ed33l5BNIRScYTLMTubp0GKaqZxt4ZV79D71caNsK6gDjG0nr6007/AJot2E9cevvSFY4Qghco2W7VJCpEmPK3KO/tUUSttGMncCeaniJABJyGHY0IY5RvGDtXb1GaljGR1BI6+1NXb5bHPbPSpIxtB6cgj3IoAcm7zPRD0z/FUypwGPHbjjj0qOP/AFfLcKMZPP6VYQEKpIBUdfrQAqD5cANgHkZzj3r2b4AafDrHhbxr4fe6s0udQ00rDCeLiUr82F7ba8cRWO4joRxgV1fwz8QHwv410zXCoaO3m/eg/wASEYIP4VMloXTdmefWgmtroQHckisVYZ54yDn8q6mPX729R/s4eN1jVT5RwMdMmt/9oLwlbaF4tGs6BILjQ9aX7XazpyFJPzIPTBrg4JpFD+S3lCSTa/OAfb6VkrMuUpQPVvC/iKz8NvHdz2g82XHlD72/j71e7+F/H+nXFqq3N1EjhQXJYBVPpXyXptpc6grO97HA1up8ts8bemAf6V0Flf6PFprQFcxR8yy8l5m7AZ6Vy4jCqWqPTwmN5VaR734++I7aPJAbS6W5adv3EcZGCPU1h6d8ZNW+0SR3cCrBAVDvtyWJPOPUV5Z4Yln1OWOKzsoppNwAdmJ2Ln7vt9a9IfSI7DSrvWL2OKa7lYwRIqgJbhR8xGevFcqp8h3e2dTbRHX+Fvi/BqurtYXlosYA+V8Z57CvTtMvYry3EpiEYbpnrXzP4N09YLaxnuIv3d5qGVugeQnp+fNdF4h8Xax4Yu1i+1me1eRlVyeVYHpUycm9DSMkoXke5avqltY28txJKipGPmJPArz4eJ5NQ14ywcQwuBKM9R1Dj0ryPxf4s1Pz54ftLPDdJ5nJzgEZKkVk+HdZvY7Ge5tnm2mSNGJ7pjkVrChKSuznnjI03yo+prbVIrxxFvxtUZ55JzTr/VY4meEOA4HAJ6/SvG7DxJGtrbyRXI8wYlcKeeeg+nSt/T7q71m42ovmSSvtBPUA85FR7J9TVV4taHrXw9jbyrvU5Edm24UZ5OB2r568X3/2jWL6dfNRXnYhZPvDnpX0Rr8tv4b+H00c119lmeAqjKOd5HavmPUd8hZnbcSCWyepPOa9OhBKJ5GIqc02ZV5I5IBBPHB6cVnMy7ceUvygkEnlgf8ACtL5R+5OHVwMgnpiqtxhwCnl4PYDmujY45MypQdvA24JJGOp7VB5fBOGLYw2TWlIhG75iPmGR/Sq0wOfnC7j144qjKxSZdpK4OMY6f1qNgWIYDC9AB61oGApbkkkLg4B4GarYICqQOvYd6aVwKflBGCghTgklj0qHaqfMpyzDGT0P4VcmhDS7iw4A6ii48s2+5WYHr70crA84ifIwpJxnDY4wKIztG7cmDwBTUHA646VMoVsLwM8/X2qAHqMruU5GMfhUwClQyVGCoO3rjGPapYlwhUkj1HvQBMgG3ZgEc9B0qWNSI1IOQOtRwkscEAlc4qdFyhPPIzxTsBMqrheQp7V1vgHwhqPi7Vja2KpFDGvmXNxJ8scKd2J/pXO6Hp9xqmp29haRtPPNIEiXHLMe1e1XLwaLpsfg7RmVo4yP7SuI+tzOeCuf7i9MUt0aQRf13QvD2r+FbTw/oUs13aWUEkX2mVcebIW5ZR6AivnfxTo95o2py6fdIryoccDgjsR719lXegW+jW2j2ltCi/6J+8YfxMeT/OuP+JHw6tPENss0Ue2ePLJjjLY4yfSvK+sezrNS2PZeC9tQjKO58y2N2LeYwxq2xkGxn6DscjpWpfLZXSsbNkZlVAqYOWIHJqTxh4V1bQZIftVrIGVjl1B2nn1rGtnbzldSQu4s6gcg4r0YyjON0ePOnKnK0j0rw7dW2laO15BIsdy6xmKPrjB+bINdNqetSaj4dt03QyCCV2mZGzu39jXl9pq1hZ6bDEtq818hG5pCSvPYirOj6ubfTi+5VmeZ1dScALjqPxNRKlFs2jXcVY7/SfFCT2mjWMkUUUdjHKzIDjJ7GuX1K9h1W3jkvJxGXuf3yseQGHBH0rCmle8eS9luCJQnRRgBBjOT3zV9bewuGuHt5RcgWuSSMANnn/9VP2MEOeKnKNiibtIjcwkm5d2Xaw5GBnOPfFbNhdWlnpSiC1Z3lLR5PVlJGOPzqre2Vta2NiE2yy7WaZIhnknAFXvJkuZbOOSNgIAGDIeGGP6ZptWRhFuTN/RbRp79be3KhlOyNAvODhjmvoH4LeF5bdPtuow5ZTiMt2xXIfA3wrp0twNTvLuJjEuTHnkfX3r3QulzpN3BpeIpFjIjIHfFYPllI7Y80InlHxx183d2ukwhTDb/OHQ53HHIrx28UE7sHpyAK63Xbe5F5Msyt5gYhtx5z3rnbqNmiOAdwPFdNNHLO9zCljVywAXgA5xjrULxjdgLhRnI7n3rTmiJ5HXGM+lVWXaZBgszDnNaWM5K5miPLK4ByAeRUEyM6ljhj3bFahQ5JGM4xjpVWRfLlbAIXPBHShkNGbKoIHBLDrnoRTGgJLFTjHTmr7w7sbskYzx1qFo8FjyvOQ3tTTsIoFVaQ5JBB9KgKuAWZAQDt/Cr/lMF83BO8/KM9qrS/IM9OxGOatO4jy8B8EEAhcfrTowoDeueKZG2cENkt3/AKU9eGHPsPeshk67cBeuF5xU8aHOATnuTUCYIJjYDaPvevrViEll2sPp7CgCWLGCSME9KnjBHypwT1weK0NC8Oa9q7Y0zSLy6UnG6OElR+PSu/0PwtF4Rls9Q1pIZ9ZLF009wCsAA4aQ9N2ei0xpMd4ZtP8AhCtAGs3I26/qEZjtoHHzWsTdZT6MR0FaHgOB7nVbIN85luUBPc/N1rm/Et3c3d40txM80krfNIx5J/wr0z4GaZbX+t2zTnK2gMq+5HShIpPWx7p4lsjcWcF1GMmA4I9ulUIYg0e3gjFdVaRq8DRsODkH8axmtTBO8JH3TwT3FeLjqL5uc+hy+unD2b6HMa7oFpqVvJb3EaFZAVOQDxXjHiP4MSNqc7aXILeIjCBuc/j6V9HvAHXGAe/SqrW4VuVyPTFc9KpOGzOmrSp1fiR8fah8N/FFrq9zbR2klw0R3lx0Ix1qhP4b1pLVIv7NYPlm8wrktkdPpX2gtjA+/emdww3uKbHounqmPIQ8nsOBXXHFze559TL6aejPi6DStSW28q6tpmBw6AoRjjGcVr2OkXselLa2GnThpJFZmkGS3avrOXRdNeUs9rGxIC5KjoKaNPs4seVbxjA7KKp4xjWWR7nzfpXw98QXYRvJKb35ZuPf+dd14Y+GcULb9QuC7HIaNR8o9q9WW2Zj0Cg8YFW4LIAZwOOawni5M6aeBpwOe0nRbbTIkis4vLRR1Hf612djeTWfhu4v4yQY3Uj3GRmq0No1xIIY1wW6n0FTePpItI8D3CKdoJSNc9yTVYSE5S53sLG1IKCprc5n4raKknk65Zp+5uV/eY6Bq8ourdgzDGcDgV7H4P8AEen3+jvououNkh2oc/dBrg/FuizaTqMltN25Ujo6noRXq05HizicJLENrsQQWHHsareXiTLYwBjNbF1BtUbjxjoO9U3jGcHgHGOOlbGEjLeAxhV4OTx71A0e1x5nzKOSBWnNAXIyR7VXmhCjIO0ng8Z5pbkMy3jJ2gkEk4+uagfcrtGQBuIOccVovENpL/KBjGe5qrMrZcq5696ajcTKHlnYVAZlPXB96hnR3JUoMggY9q0HJcqCFUKuMAYzVWZJFl3xjbjOc9aq1hPU8b5B3A4wfzFdJ4d8H+JNc8r7Dpk5hYFlnkHlxAA8nceK1o/EWhacyDw34WtldWJW71B/PkYZ4O37oIqtqmva9rAC6lqdxLEAdsIfZGmT0CrwKiwbGvZeDfDmmhZPEniq3L7sPZ6cnnSD1+b7tadl4h8L6LNH/wAI94RhnlTOLrVZDKTxjOwcCuNt4SAcZAHt1960ISkfylVIPUniq5bbhzHVzeM/FOqRR6dJqssNsRgRW2IY1UdsLjNTbDI3zSPI7Hlwclvck1neFbAeS92cfN8qEkHgda25SilXwRgcdgTnmqsh3uZV/BjaXYKvQ85Nd38GtX/svXrZ5kIhkbYznng8f4VylxAHDAAEdzjNX/D3JXaGG3ge1DWhK0PrnTH+Yr69KfqttvjEyffTn6iuU+FesnV9JgaVy88P7qUn26Gu4Dxk7S68cHmuSrDmXKd1Go4u5hqFZQw6GmSR5HNXZ4RBcbOCj8qR/KmNH7V5MqTi7HtQq8yuVY4xjFSeX6HIp4TBzilxgd6hKyLcrlSaEk0zyfXNXmUmo2Q+9Q0Wp2RVjhAYkLVmKF5nEaKT6nsKmggediE4UdSa1baFIFxGjknqcda6KFDnepzYjFKCshLC1jtkKjljyzHqa5P4z6Zc6l4Gne0Zt9m4uCo/iA6j8q6y9ubawtftN7MtvFuC7n4AJOBUmYbq2PKywyLtbachlPBr1Iw5VZHkSm5O7Pk7TtXlgcFZDx0ya9W0PWtL8W6LFpOqTCC9h4guG9PQ15L8RNKl8MeMr/TGUrEj+ZEcdY25H+FUNL1l42Vo3IYHjmly2d0WpXVmeqa34H1i0t2miSO8hxnfB8wrj7i0kil/eBlOcEMOn1rW0HxdfWsXmWl3KpHBAbj8q6RPE2j62oh8QaahkbH+kwAK4+o71pGTMpQR5tNExJyBjPJHHFQSxkxjjkjgHtXpWo+Bormxa78PXqainXygcSD8K4y7sbiG4aGeFo5BnKsMdK0UkzOUWc48G8hHfB79xULRMEOAPnPQmtq4hKgkDGBkA9zVF4t+BgKFG4+tVexlaxkrAASQSOSrGoZUdRtXoR1Zu1ac9syFSDu3gnA7VXvrcphWKk46g9qqJLP/2Q==" alt="M. Tayyab" width="96" height="96" />
                <div>
                  <h3 style={{fontSize:"1.4rem",margin:"0"}}>
                    M. Tayyab
                  </h3>
                  <p style={{color:"var(--mint)",fontWeight:"600"}}>
                    CEO, Loadhub Marketing
                  </p>
                  <div className="act" style={{marginTop:"12px"}}>
                    <a className="pill t" href="#" aria-label="LinkedIn">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-linkedin-in" />
                      </svg>
                      {" LinkedIn"}
                    </a>
                    <a className="pill t" href="https://t.me/Loadhub_america" target="_blank" rel="noopener">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-telegram" />
                      </svg>
                      {" Telegram"}
                    </a>
                    <a className="pill t" href="#" aria-label="Teams">
                      <svg className="i" aria-hidden="true">
                        <use href="#brands-microsoft" />
                      </svg>
                      {" Teams"}
                    </a>
                  </div>
                </div>
              </div>
              <div className="icard">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-envelope" />
                </svg>
                <div>
                  <small>
                    Email
                  </small>
                  <b>
                    <a href="mailto:Marketing@loadhubamerica.com">
                      Marketing@loadhubamerica.com
                    </a>
                  </b>
                </div>
              </div>
              <div className="icard">
                <svg className="i" aria-hidden="true">
                  <use href="#brands-telegram" />
                </svg>
                <div>
                  <small>
                    Telegram
                  </small>
                  <b>
                    <a href="https://t.me/Loadhub_america" target="_blank" rel="noopener">
                      @Loadhub_america
                    </a>
                  </b>
                </div>
              </div>
              <div className="icard">
                <svg className="i" aria-hidden="true">
                  <use href="#brands-whatsapp" />
                </svg>
                <div>
                  <small>
                    WhatsApp
                  </small>
                  <b>
                    <a href="https://wa.me/16468956658" target="_blank" rel="noopener">
                      +1 (646) 895-6658
                    </a>
                  </b>
                </div>
              </div>
              <div className="icard">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-location-dot" />
                </svg>
                <div>
                  <small>
                    Location
                  </small>
                  <b>
                    22518 Woodcreek Dr, Brownstown Twp, MI 48134, United States
                  </b>
                </div>
              </div>
            </div>
            <div className="card">
              <h3 style={{fontSize:"1.5rem"}}>
                Send a message
              </h3>
              <p style={{marginBottom:"18px"}}>
                We reply within 24 hours.
              </p>
              <form name="partner" method="POST" data-lead="">
                <input type="hidden" name="form-name" value="partner" />
                <p className="hp">
                  <label>
                    {"Leave empty "}
                    <input name="bot-field" />
                  </label>
                </p>
                <div className="row">
                  <div>
                    <label htmlFor="f-c">
                      First name *
                    </label>
                    <input id="f-c" name="first" required autoComplete="given-name" placeholder="John" />
                  </div>
                  <div>
                    <label htmlFor="l-c">
                      Last name *
                    </label>
                    <input id="l-c" name="last" required autoComplete="family-name" placeholder="Smith" />
                  </div>
                </div>
                <div className="row">
                  <div>
                    <label htmlFor="e-c">
                      Email *
                    </label>
                    <input id="e-c" name="email" type="email" required autoComplete="email" placeholder="john@company.com" />
                  </div>
                  <div>
                    <label htmlFor="p-c">
                      Phone
                    </label>
                    <input id="p-c" name="phone" type="tel" autoComplete="tel" placeholder="+1 234 567 8900" />
                  </div>
                </div>
                <div className="row">
                  <div>
                    <label htmlFor="v-c">
                      Vertical *
                    </label>
                    <select id="v-c" name="service" required>
                      <option value="">
                        Select vertical
                      </option>
                      <optgroup label="Personal">
                        <option value="Auto Insurance">
                          Auto Insurance
                        </option>
                        <option value="Home Insurance">
                          Home Insurance
                        </option>
                        <option value="Health Insurance">
                          Health Insurance
                        </option>
                        <option value="Life Insurance">
                          Life Insurance
                        </option>
                        <option value={"Dental & Vision"}>
                          Dental &amp; Vision
                        </option>
                        <option value="Travel Insurance">
                          Travel Insurance
                        </option>
                        <option value="Pet Insurance">
                          Pet Insurance
                        </option>
                        <option value="Umbrella Insurance">
                          Umbrella Insurance
                        </option>
                        <option value={"Flood & Earthquake Insurance"}>
                          Flood &amp; Earthquake Insurance
                        </option>
                      </optgroup>
                      <optgroup label="Business">
                        <option value="General Liability">
                          General Liability
                        </option>
                        <option value="Commercial Auto">
                          Commercial Auto
                        </option>
                        <option value="Workers’ Compensation">
                          Workers’ Compensation
                        </option>
                        <option value={"Professional Liability (E&O)"}>
                          Professional Liability (E&amp;O)
                        </option>
                        <option value="Business Owner’s Policy (BOP)">
                          Business Owner’s Policy (BOP)
                        </option>
                        <option value="Cyber Insurance">
                          Cyber Insurance
                        </option>
                        <option value="Commercial Property">
                          Commercial Property
                        </option>
                        <option value="Group Health">
                          Group Health
                        </option>
                      </optgroup>
                      <optgroup label="Special">
                        <option value="Disability Insurance">
                          Disability Insurance
                        </option>
                        <option value="Long-Term Care">
                          Long-Term Care
                        </option>
                        <option value="Annuities / Retirement">
                          Annuities / Retirement
                        </option>
                        <option value="Trucking Insurance">
                          Trucking Insurance
                        </option>
                      </optgroup>
                      <optgroup label="Finance">
                        <option value="Personal Loans">
                          Personal Loans
                        </option>
                        <option value="Debt Relief">
                          Debt Relief
                        </option>
                        <option value="Credit Repair">
                          Credit Repair
                        </option>
                        <option value="Mortgage">
                          Mortgage
                        </option>
                        <option value="Tax Help">
                          Tax Help
                        </option>
                      </optgroup>
                      <optgroup label="Other">
                        <option>
                          Partner with us
                        </option>
                        <option>
                          Other
                        </option>
                      </optgroup>
                    </select>
                  </div>
                  <div>
                    <label htmlFor="d-c">
                      Deal type *
                    </label>
                    <select id="d-c" name="dealtype" required>
                      <option value="">
                        Select type
                      </option>
                      <option>
                        CPL
                      </option>
                      <option>
                        CPA
                      </option>
                      <option>
                        Direct Advertiser
                      </option>
                      <option>
                        Affiliate Network
                      </option>
                      <option>
                        Broker
                      </option>
                      <option>
                        Other
                      </option>
                    </select>
                  </div>
                </div>
                <div>
                  <label htmlFor="m-c">
                    Message *
                  </label>
                  <textarea id="m-c" name="message" rows="5" required placeholder="Tell us about your goals and partnership needs" />
                </div>
                <label className="chk">
                  <input type="checkbox" name="consent" value="yes" required />
                  <span>
                    {"I agree to be contacted by Loadhub Marketing by phone, text or email and accept the "}
                    <Link to="/privacy.html" style={{textDecoration:"underline"}}>
                      Privacy Policy
                    </Link>
                    .
                  </span>
                </label>
                {" "}
                <button className="btn p" type="submit" style={{justifyContent:"center"}}>
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-paper-plane" />
                  </svg>
                  {" Send message"}
                </button>
                <p className="rt">
                  <svg className="i" aria-hidden="true">
                    <use href="#solid-clock" />
                  </svg>
                  {" We reply within 24 hours"}
                </p>
              </form>
              <div className="ok">
                <svg className="i" aria-hidden="true">
                  <use href="#solid-circle-check" />
                </svg>
                <h3>
                  Message received
                </h3>
                <p>
                  We will reply within 24 hours. For a faster answer, message us on WhatsApp.
                </p>
                <p className="err" style={{display:"none",color:"#d9480f"}}>
                  Automatic delivery is unavailable right now. Please use WhatsApp or email Marketing@loadhubamerica.com.
                </p>
                <br />
                <a className="btn s wal" target="_blank" rel="noopener" href="#">
                  <svg className="i" aria-hidden="true">
                    <use href="#brands-whatsapp" />
                  </svg>
                  {" Continue on WhatsApp"}
                </a>
              </div>
              <p style={{textAlign:"center",fontSize:".9rem",marginTop:"14px"}}>
                {"Sent to "}
                <a href="mailto:Marketing@loadhubamerica.com" style={{color:"var(--blue)"}}>
                  Marketing@loadhubamerica.com
                </a>
              </p>
            </div>
          </div>
        </section>
      </main>
  )
}
