export const head = {
  "title": "Disclaimer and Compliance | Loadhub Marketing",
  "tags": [
    {
      "name": "description",
      "content": "Loadhub Marketing is a lead generation company, not an insurer or lender. Read our disclaimer and consent practices."
    },
    {
      "name": "robots",
      "content": "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"
    },
    {
      "property": "og:type",
      "content": "website"
    },
    {
      "property": "og:title",
      "content": "Disclaimer and Compliance | Loadhub Marketing"
    },
    {
      "property": "og:description",
      "content": "Loadhub Marketing is a lead generation company, not an insurer or lender. Read our disclaimer and consent practices."
    },
    {
      "property": "og:url",
      "content": "https://loadhubmarketing.com/disclaimer.html"
    },
    {
      "property": "og:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    },
    {
      "property": "og:image:width",
      "content": "1200"
    },
    {
      "property": "og:image:height",
      "content": "630"
    },
    {
      "property": "og:image:alt",
      "content": "Loadhub Marketing, insurance lead generation"
    },
    {
      "property": "og:site_name",
      "content": "Loadhub Marketing"
    },
    {
      "property": "og:locale",
      "content": "en_US"
    },
    {
      "name": "twitter:card",
      "content": "summary_large_image"
    },
    {
      "name": "twitter:title",
      "content": "Disclaimer and Compliance | Loadhub Marketing"
    },
    {
      "name": "twitter:description",
      "content": "Loadhub Marketing is a lead generation company, not an insurer or lender. Read our disclaimer and consent practices."
    },
    {
      "name": "twitter:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    }
  ],
  "canonical": "https://loadhubmarketing.com/disclaimer.html"
}

export default function Disclaimer() {
  return (
    <main>
        <section className="phead">
          <div className="wrap doc">
            <h1 style={{fontSize:"clamp(2rem,4.5vw,3rem)"}}>
              Disclaimer and Compliance
            </h1>
            <p>
              Last updated: 2026
            </p>
            <h2>
              We are a lead generation company
            </h2>
            <p>
              Loadhub Marketing is a marketing and lead generation company. We are not an insurance carrier, insurance agency, broker, lender or financial advisor, and we do not issue policies or loans.
            </p>
            <h2>
              Partners make the offers
            </h2>
            <p>
              Quotes, rates, coverage and approvals come from independent third-party advertisers. Availability varies by state and individual circumstances, and we cannot guarantee any rate, approval or savings.
            </p>
            <h2>
              Advertising disclosure
            </h2>
            <p>
              We may be paid by advertisers when consumers submit information through our website or campaigns.
            </p>
            <h2>
              Consent and TCPA
            </h2>
            <p>
              Consumers are contacted only after they submit a request and agree to be contacted. Consent language is shown at the point of submission, and consumers can withdraw consent at any time by emailing Marketing@loadhubamerica.com.
            </p>
            <h2>
              Not professional advice
            </h2>
            <p>
              Information on this site is general and is not insurance, legal, tax or medical advice. Please consult a licensed professional before making decisions.
            </p>
          </div>
        </section>
      </main>
  )
}
