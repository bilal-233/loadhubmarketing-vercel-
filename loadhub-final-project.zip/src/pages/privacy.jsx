export const head = {
  "title": "Privacy Policy | Loadhub Marketing",
  "tags": [
    {
      "name": "description",
      "content": "How Loadhub Marketing collects, uses and protects your information."
    },
    {
      "name": "robots",
      "content": "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1"
    },
    {
      "property": "og:type",
      "content": "website"
    },
    {
      "property": "og:title",
      "content": "Privacy Policy | Loadhub Marketing"
    },
    {
      "property": "og:description",
      "content": "How Loadhub Marketing collects, uses and protects your information."
    },
    {
      "property": "og:url",
      "content": "https://loadhubmarketing.com/privacy.html"
    },
    {
      "property": "og:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    },
    {
      "property": "og:image:width",
      "content": "1200"
    },
    {
      "property": "og:image:height",
      "content": "630"
    },
    {
      "property": "og:image:alt",
      "content": "Loadhub Marketing, insurance lead generation"
    },
    {
      "property": "og:site_name",
      "content": "Loadhub Marketing"
    },
    {
      "property": "og:locale",
      "content": "en_US"
    },
    {
      "name": "twitter:card",
      "content": "summary_large_image"
    },
    {
      "name": "twitter:title",
      "content": "Privacy Policy | Loadhub Marketing"
    },
    {
      "name": "twitter:description",
      "content": "How Loadhub Marketing collects, uses and protects your information."
    },
    {
      "name": "twitter:image",
      "content": "https://loadhubmarketing.com/og-image.png"
    }
  ],
  "canonical": "https://loadhubmarketing.com/privacy.html"
}

export default function Privacy() {
  return (
    <main>
        <section className="phead">
          <div className="wrap doc">
            <h1 style={{fontSize:"clamp(2rem,4.5vw,3rem)"}}>
              Privacy Policy
            </h1>
            <p>
              Last updated: 2026
            </p>
            <h2>
              Who we are
            </h2>
            <p>
              Loadhub Marketing (“we”, “us”) is a lead generation company. You can reach us at Marketing@loadhubamerica.com or by mail at 22518 Woodcreek Dr, Brownstown Twp, MI 48134, United States.
            </p>
            <h2>
              Information we collect
            </h2>
            <p>
              When you submit a form or chat with us we collect your name, phone number, email address, the service you are interested in, and any message you write. We also collect basic technical data such as IP address, browser type and pages visited.
            </p>
            <h2>
              How we use it
            </h2>
            <ul>
              <li>
                To respond to your request and contact you about the service you selected
              </li>
              <li>
                To share your details with advertising partners that can offer that service
              </li>
              <li>
                To improve our website and prevent fraud
              </li>
            </ul>
            <h2>
              Sharing
            </h2>
            <p>
              We share information with advertisers, networks and service providers who help us deliver leads or run our site. We do not sell your information to unrelated third parties.
            </p>
            <h2>
              Cookies
            </h2>
            <p>
              We use cookies and similar tools for analytics and to remember settings such as your theme choice. You can control cookies in your browser.
            </p>
            <h2>
              Your choices
            </h2>
            <p>
              You can ask us to access, correct or delete your information, or stop contacting you, by emailing Marketing@loadhubamerica.com. Residents of some states, including California, have additional rights under state privacy laws.
            </p>
            <h2>
              Security and retention
            </h2>
            <p>
              We use reasonable safeguards to protect your data and keep it only as long as needed for the purposes above or as required by law.
            </p>
            <h2>
              Changes
            </h2>
            <p>
              We may update this policy and will post the new date on this page.
            </p>
          </div>
        </section>
      </main>
  )
}
