export default function Icon({ id, className = 'i' }) {
  return (
    <svg aria-hidden="true" className={className}>
      <use href={`#${id}`} />
    </svg>
  )
}
